

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var NumberInput: UITextField!
    @IBOutlet weak var English: UILabel!
    @IBOutlet weak var Indonesian: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func Enter(_ sender: Any)
    {
        English.text = ""
        Indonesian.text = ""
        if NumberInput.text == "0"
        {
            English.text = "zero"
            Indonesian.text = "kosong"
            
        }
        if NumberInput.text == "1"
        {
            English.text = "one"
            Indonesian.text = "satu"
            
        }
        if NumberInput.text == "2"
        {
            English.text = "two"
            Indonesian.text = "dua"
            
        }
        if NumberInput.text == "3"
        {
            English.text = "three"
            Indonesian.text = "tiga"
            
        }
        if NumberInput.text == "4"
        {
            English.text = "four"
            Indonesian.text = "empat"
            
        }
        if NumberInput.text == "5"
        {
            English.text = "five"
            Indonesian.text = "lima"
            
        }
        if NumberInput.text == "6"
        {
            English.text = "six"
            Indonesian.text = "enam"
            
        }
        if NumberInput.text == "7"
        {
            English.text = "seven"
            Indonesian.text = "tujuh"
            
        }
        if NumberInput.text == "8"
        {
            English.text = "eight"
            Indonesian.text = "delapan"
            
        }
        if NumberInput.text == "9"
        {
            English.text = "nine"
            Indonesian.text = "sembilan"
            
        }
        if NumberInput.text == "10"
        {
            English.text = "ten"
            Indonesian.text = "sepuluh"
            
        }
        if NumberInput.text == "11"
        {
            English.text = "eleven"
            Indonesian.text = "sebelas"
            
        }
        if NumberInput.text == "12"
        {
            English.text = "twelve"
            Indonesian.text = "dua belas"
            
        }
        if NumberInput.text == "13"
        {
            English.text = "thirteen"
            Indonesian.text = "tiga belas"
            
        }
        if NumberInput.text == "14"
        {
            English.text = "fourteen"
            Indonesian.text = "empat belas"
            
        }
        if NumberInput.text == "15"
        {
            English.text = "fifteen"
            Indonesian.text = "lima belas"
            
        }
        if NumberInput.text == "16"
        {
            English.text = "sixteen"
            Indonesian.text = "enam belas"
            
        }
        if NumberInput.text == "17"
        {
            English.text = "seventeen"
            Indonesian.text = "tujuh belas"
            
        }
        if NumberInput.text == "18"
        {
            English.text = "eighteen"
            Indonesian.text = "delapan belas"
            
        }
        if NumberInput.text == "19"
        {
            English.text = "nineteen"
            Indonesian.text = "sembilan belas"
            
        }
        if NumberInput.text == "20"
        {
            English.text = "twenty"
            Indonesian.text = "dua puluh"
            
        }
        if NumberInput.text == "21"
        {
            English.text = "twenty one"
            Indonesian.text = "dua puluh satu"
            
        }
        if NumberInput.text == "22"
        {
            English.text = "twenty two"
            Indonesian.text = "dua puluh dua"
            
        }
        if NumberInput.text == "23"
        {
            English.text = "twenty three"
            Indonesian.text = "dua puluh tiga"
            
        }
        if NumberInput.text == "24"
        {
            English.text = "twenty four"
            Indonesian.text = "dua puluh empat"
            
        }
        if NumberInput.text == "25"
        {
            English.text = "twenty five"
            Indonesian.text = "dua puluh lima"
            
        }
        if NumberInput.text == "26"
        {
            English.text = "twenty six"
            Indonesian.text = "dua puluh enam"
            
        }
        if NumberInput.text == "27"
        {
            English.text = "twenty seven"
            Indonesian.text = "dua puluh tujuh"
            
        }
        if NumberInput.text == "28"
        {
            English.text = "twenty eight"
            Indonesian.text = "dua puluh delapan"
            
        }
        if NumberInput.text == "29"
        {
            English.text = "twenty nine"
            Indonesian.text = "dua puluh sembilan"
            
        }
        if NumberInput.text == "30"
        {
            English.text = "thirty"
            Indonesian.text = "tiga puluh"
            
        }
        if NumberInput.text == "31"
        {
            English.text = "thirty one"
            Indonesian.text = "satu"
            
        }
        if NumberInput.text == "32"
        {
            English.text = "thirty two"
            Indonesian.text = "tiga puluh dua"
            
        }
        if NumberInput.text == "33"
        {
            English.text = "thirty three"
            Indonesian.text = "tiga puluh tiga"
            
        }
        if NumberInput.text == "34"
        {
            English.text = "thirty four"
            Indonesian.text = "tiga puluh empat"
            
        }
        if NumberInput.text == "35"
        {
            English.text = "thirty five"
            Indonesian.text = "tiga puluh lima"
            
        }
        if NumberInput.text == "36"
        {
            English.text = "thirty six"
            Indonesian.text = "tiga puluh enam"
            
        }
        if NumberInput.text == "37"
        {
            English.text = "thirty seven"
            Indonesian.text = "tiga puluh tujuh"
            
        }
        if NumberInput.text == "38"
        {
            English.text = "thirty eight"
            Indonesian.text = "tiga puluh delapan"
            
        }
        if NumberInput.text == "39"
        {
            English.text = "thirty nine"
            Indonesian.text = "tiga puluh sembilan"
            
        }
        if NumberInput.text == "40"
        {
            English.text = "forty"
            Indonesian.text = "empat puluh"
            
        }
        if NumberInput.text == "41"
        {
            English.text = "forty one"
            Indonesian.text = "empat puluh satu"
            
        }
        if NumberInput.text == "42"
        {
            English.text = "forty two"
            Indonesian.text = "empat puluh dua"
            
        }
        if NumberInput.text == "43"
        {
            English.text = "forty three"
            Indonesian.text = "empat puluh tiga"
            
        }
        if NumberInput.text == "44"
        {
            English.text = "forty four"
            Indonesian.text = "empat puluh empat"
            
        }
        if NumberInput.text == "45"
        {
            English.text = "forty five"
            Indonesian.text = "empat puluh lima"
            
        }
        if NumberInput.text == "46"
        {
            English.text = "forty six"
            Indonesian.text = "empat puluh enam"
            
        }
        if NumberInput.text == "47"
        {
            English.text = "forty seven"
            Indonesian.text = "empat puluh tujuh"
            
        }
        if NumberInput.text == "48"
        {
            English.text = "forty eight"
            Indonesian.text = "empat puluh delapan"
            
        }
        if NumberInput.text == "49"
        {
            English.text = "forty nine"
            Indonesian.text = "empat puluh sembilan"
            
        }
        if NumberInput.text == "50"
        {
            English.text = "fifty"
            Indonesian.text = "lima puluh"
            
        }
        if NumberInput.text == "51"
        {
            English.text = "fifty one"
            Indonesian.text = "lima puluh satu"
            
        }
        if NumberInput.text == "52"
        {
            English.text = "fifty two"
            Indonesian.text = "lima puluh dua"
            
        }
        if NumberInput.text == "53"
        {
            English.text = "fifty three"
            Indonesian.text = "lima puluh tiga"
            
        }
        if NumberInput.text == "54"
        {
            English.text = "fifty four"
            Indonesian.text = "lima puluh empat"
            
        }
        if NumberInput.text == "55"
        {
            English.text = "fifty five"
            Indonesian.text = "lima puluh lima"
            
        }
        if NumberInput.text == "56"
        {
            English.text = "fifty six"
            Indonesian.text = "lima puluh enam"
            
        }
        if NumberInput.text == "57"
        {
            English.text = "fifty seven"
            Indonesian.text = "lima puluh tujuh"
            
        }
        if NumberInput.text == "58"
        {
            English.text = "fifty eight"
            Indonesian.text = "lima puluh delapan"
            
        }
        if NumberInput.text == "59"
        {
            English.text = "fifty nine"
            Indonesian.text = "lima puluh sembilan"
            
        }
        if NumberInput.text == "60"
        {
            English.text = "sixty"
            Indonesian.text = "enam puluh"
            
        }
        if NumberInput.text == "61"
        {
            English.text = "sixty one"
            Indonesian.text = "enam puluh satu"
            
        }
        if NumberInput.text == "62"
        {
            English.text = "sixty two"
            Indonesian.text = "enam puluh dua"
            
        }
        if NumberInput.text == "63"
        {
            English.text = "sixty three"
            Indonesian.text = "enam puluh tiga"
            
        }
        if NumberInput.text == "64"
        {
            English.text = "sixty four"
            Indonesian.text = "enam puluh empat"
            
        }
        if NumberInput.text == "65"
        {
            English.text = "sixty five"
            Indonesian.text = "enam puluh lima"
            
        }
        if NumberInput.text == "66"
        {
            English.text = "sixty six"
            Indonesian.text = "enam puluh enam"
            
        }
        if NumberInput.text == "67"
        {
            English.text = "sixty seven"
            Indonesian.text = "enam puluh tujuh"
            
        }
        if NumberInput.text == "68"
        {
            English.text = "sixty eight"
            Indonesian.text = "enam puluh delapan"
            
        }
        if NumberInput.text == "69"
        {
            English.text = "sixty nine"
            Indonesian.text = "enam puluh sembilan"
            
        }
        if NumberInput.text == "70"
        {
            English.text = "seventy"
            Indonesian.text = "tujuh puluh"
            
        }
        if NumberInput.text == "71"
        {
            English.text = "seventy one"
            Indonesian.text = "tujuh puluh satu"
            
        }
        if NumberInput.text == "72"
        {
            English.text = "seventy two"
            Indonesian.text = "tujuh puluh dua"
            
        }
        if NumberInput.text == "73"
        {
            English.text = "seventy three"
            Indonesian.text = "tujuh puluh tiga"
            
        }
        if NumberInput.text == "74"
        {
            English.text = "seventy four"
            Indonesian.text = "tujuh puluh empat"
            
        }
        if NumberInput.text == "75"
        {
            English.text = "seventy five"
            Indonesian.text = "tujuh puluh lima"
            
        }
        if NumberInput.text == "76"
        {
            English.text = "seventy six"
            Indonesian.text = "tujuh puluh enam"
            
        }
        if NumberInput.text == "77"
        {
            English.text = "seventy seven"
            Indonesian.text = "tujuh puluh tujuh"
            
        }
        if NumberInput.text == "78"
        {
            English.text = "seventy eight"
            Indonesian.text = "tujuh puluh delapan"
            
        }
        if NumberInput.text == "79"
        {
            English.text = "seventy nine"
            Indonesian.text = "tujuh puluh sembilan"
            
        }
        if NumberInput.text == "80"
        {
            English.text = "eighty"
            Indonesian.text = "delapan puluh"
            
        }
        if NumberInput.text == "81"
        {
            English.text = "eighty one"
            Indonesian.text = "delapan puluh satu"
            
        }
        if NumberInput.text == "82"
        {
            English.text = "eighty two"
            Indonesian.text = "delapan puluh dua"
            
        }
        if NumberInput.text == "83"
        {
            English.text = "eighty three"
            Indonesian.text = "delapan puluh tiga"
            
        }
        if NumberInput.text == "84"
        {
            English.text = "eighty four"
            Indonesian.text = "delapan puluh empat"
            
        }
        if NumberInput.text == "85"
        {
            English.text = "eighty five"
            Indonesian.text = "delapan puluh lima"
            
        }
        if NumberInput.text == "86"
        {
            English.text = "eighty six"
            Indonesian.text = "delapan puluh enam"
            
        }
        if NumberInput.text == "87"
        {
            English.text = "eighty seven"
            Indonesian.text = "delapan puluh tujuh"
            
        }
        if NumberInput.text == "88"
        {
            English.text = "eighty eight"
            Indonesian.text = "delapan puluh delapan"
            
        }
        if NumberInput.text == "89"
        {
            English.text = "eighty nine"
            Indonesian.text = "delapan puluh sembilan"
            
        }
        if NumberInput.text == "90"
        {
            English.text = "ninety"
            Indonesian.text = "sembilan puluh"
            
        }
        if NumberInput.text == "91"
        {
            English.text = "ninety one"
            Indonesian.text = "sembilan puluh satu"
            
        }
        if NumberInput.text == "92"
        {
            English.text = "ninety two"
            Indonesian.text = "sembilan puluh dua"
            
        }
        if NumberInput.text == "93"
        {
            English.text = "ninety three"
            Indonesian.text = "sembilan puluh tiga"
            
        }
        if NumberInput.text == "94"
        {
            English.text = "ninety four"
            Indonesian.text = "sembilan puluh empat"
            
        }
        if NumberInput.text == "95"
        {
            English.text = "ninety five"
            Indonesian.text = "sembilan puluh lima"
            
        }
        if NumberInput.text == "96"
        {
            English.text = "ninety six"
            Indonesian.text = "sembilan puluh enam"
            
        }
        if NumberInput.text == "97"
        {
            English.text = "ninety seven"
            Indonesian.text = "sembilan puluh tujuh"
            
        }
        if NumberInput.text == "98"
        {
            English.text = "ninety eight"
            Indonesian.text = "sembilan puluh delapan"
            
        }
        if NumberInput.text == "99"
        {
            English.text = "ninety nine"
            Indonesian.text = "sembilan puluh sembilan"
            
        }
        if NumberInput.text == "100"
        {
            English.text = "one hundred"
            Indonesian.text = "seratus"
            
        }
        if NumberInput.text == "101"
        {
            English.text = "one hundred and one"
            Indonesian.text = "seratus satu"
            
        }
        if NumberInput.text == "102"
        {
            English.text = "one hundred and two"
            Indonesian.text = "seratus dua"
            
        }
        if NumberInput.text == "103"
        {
            English.text = "one hundred and three"
            Indonesian.text = "seratus tiga"
            
        }
        if NumberInput.text == "104"
        {
            English.text = "one hundred and four"
            Indonesian.text = "seratus empat"
            
        }
        if NumberInput.text == "105"
        {
            English.text = "one hundred and five"
            Indonesian.text = "seratus lima"
            
        }
        if NumberInput.text == "106"
        {
            English.text = "one hundred and six"
            Indonesian.text = "seratus enam"
            
        }
        if NumberInput.text == "107"
        {
            English.text = "one hundred and seven"
            Indonesian.text = "seratus tujuh"
            
        }
        if NumberInput.text == "108"
        {
            English.text = "one hundred and eight"
            Indonesian.text = "seratus delapan"
            
        }
        if NumberInput.text == "109"
        {
            English.text = "one hundred and nine"
            Indonesian.text = "seratus sembilan"
            
        }
        if NumberInput.text == "110"
        {
            English.text = "one hundred and ten"
            Indonesian.text = "seratus sepuluh"
            
        }
        if NumberInput.text == "111"
        {
            English.text = "one hundred and eleven"
            Indonesian.text = "seratus sebelas"
            
        }
        if NumberInput.text == "112"
        {
            English.text = "one hundred and twelve"
            Indonesian.text = "seratus dua belas"
            
        }
        if NumberInput.text == "113"
        {
            English.text = "one hundred and thirteen"
            Indonesian.text = "seratus tiga belas"
            
        }
        if NumberInput.text == "114"
        {
            English.text = "one hundred and fourteen"
            Indonesian.text = "seratus empat belas"
            
        }
        if NumberInput.text == "115"
        {
            English.text = "one hundred and fifteen"
            Indonesian.text = "seratus lima belas"
            
        }
        if NumberInput.text == "116"
        {
            English.text = "one hundred and sixteen"
            Indonesian.text = "seratus enam belas"
            
        }
        if NumberInput.text == "117"
        {
            English.text = "one hundred and seventeen"
            Indonesian.text = "seratus tujuh belas"
            
        }
        if NumberInput.text == "118"
        {
            English.text = "one hundred and eighteen"
            Indonesian.text = "seratus delapan belas"
            
        }
        if NumberInput.text == "119"
        {
            English.text = "one hundred and nineteen"
            Indonesian.text = "seratus sembilan belas"
            
        }
        if NumberInput.text == "120"
        {
            English.text = "one hundred and twenty"
            Indonesian.text = "seratus dua puluh"
            
        }
        if NumberInput.text == "121"
        {
            English.text = "one hundred and twenty one"
            Indonesian.text = "seratus dua puluh satu"
            
        }
        if NumberInput.text == "122"
        {
            English.text = "one hundred and twenty two"
            Indonesian.text = "seratus dua puluh dua"
            
        }
        if NumberInput.text == "123"
        {
            English.text = "one hundred and twenty three"
            Indonesian.text = "seratus dua puluh tiga"
            
        }
        if NumberInput.text == "124"
        {
            English.text = "one hundred and twenty four"
            Indonesian.text = "seratus dua puluh empat"
            
        }
        if NumberInput.text == "125"
        {
            English.text = "one hundred and twenty five"
            Indonesian.text = "seratus dua puluh lima"
            
        }
        if NumberInput.text == "126"
        {
            English.text = "one hundred and twenty six"
            Indonesian.text = "seratus dua puluh enam"
            
        }
        if NumberInput.text == "127"
        {
            English.text = "one hundred and twenty seven"
            Indonesian.text = "seratus dua puluh tujuh"
            
        }
        if NumberInput.text == "128"
        {
            English.text = "one hundred and twenty eight"
            Indonesian.text = "seratus dua puluh delapan"
            
        }
        if NumberInput.text == "129"
        {
            English.text = "one hundred and twenty nine"
            Indonesian.text = "seratus dua puluh sembilan"
            
        }
        if NumberInput.text == "130"
        {
            English.text = "one hundred and thirty"
            Indonesian.text = "seratus tiga puluh"
            
        }
        if NumberInput.text == "131"
        {
            English.text = "one hundred and thirty one"
            Indonesian.text = "seratus tiga puluh satu"
            
        }
        if NumberInput.text == "132"
        {
            English.text = "one hundred and thirty two"
            Indonesian.text = "seratus tiga puluh dua"
            
        }
        if NumberInput.text == "133"
        {
            English.text = "one hundred and thirty three"
            Indonesian.text = "seratus tiga puluh tiga"
            
        }
        if NumberInput.text == "134"
        {
            English.text = "one hundred and thirty four"
            Indonesian.text = "seratus tiga puluh empat"
            
        }
        if NumberInput.text == "135"
        {
            English.text = "one hundred and thirty five"
            Indonesian.text = "seratus tiga puluh lima"
            
        }
        if NumberInput.text == "136"
        {
            English.text = "one hundred and thirty six"
            Indonesian.text = "seratus tiga puluh enam"
            
        }
        if NumberInput.text == "137"
        {
            English.text = "one hundred and thirty seven"
            Indonesian.text = "seratus tiga puluh tujuh"
            
        }
        if NumberInput.text == "138"
        {
            English.text = "one hundred and thirty eight"
            Indonesian.text = "seratus tiga puluh delapan"
            
        }
        if NumberInput.text == "139"
        {
            English.text = "one hundred and thirty nine"
            Indonesian.text = "seratus tiga puluh sembilan"
            
        }
        if NumberInput.text == "140"
        {
            English.text = "one hundred and forty"
            Indonesian.text = "seratus empat puluh"
            
        }
        if NumberInput.text == "141"
        {
            English.text = "one hundred and forty one"
            Indonesian.text = "seratus empat puluh satu"
            
        }
        if NumberInput.text == "142"
        {
            English.text = "one hundred and forty two"
            Indonesian.text = "seratus empat puluh dua"
            
        }
        if NumberInput.text == "143"
        {
            English.text = "one hundred and forty three"
            Indonesian.text = "seratus empat puluh tiga"
            
        }
        if NumberInput.text == "144"
        {
            English.text = "one hundred and forty four"
            Indonesian.text = "seratus empat puluh empat"
            
        }
        if NumberInput.text == "145"
        {
            English.text = "one hundred and forty five"
            Indonesian.text = "seratus empat puluh lima"
            
        }
        if NumberInput.text == "146"
        {
            English.text = "one hundred and forty six"
            Indonesian.text = "seratus empat puluh enam"
            
        }
        if NumberInput.text == "147"
        {
            English.text = "one hundred and forty seven"
            Indonesian.text = "seratus empat puluh tujuh"
            
        }
        if NumberInput.text == "148"
        {
            English.text = "one hundred and forty eight"
            Indonesian.text = "seratus empat puluh delapan"
            
        }
        if NumberInput.text == "149"
        {
            English.text = "one hundred and forty nine"
            Indonesian.text = "seratus empat puluh sembilan"
            
        }
        if NumberInput.text == "150"
        {
            English.text = "one hundred and fifty"
            Indonesian.text = "seratus lima puluh"
            
        }
        if NumberInput.text == "151"
        {
            English.text = "one hundred and fifty one"
            Indonesian.text = "seratus lima puluh satu"
            
        }
        if NumberInput.text == "152"
        {
            English.text = "one hundred and fifty two"
            Indonesian.text = "seratus lima puluh dua"
            
        }
        if NumberInput.text == "153"
        {
            English.text = "one hundred and fifty three"
            Indonesian.text = "seratus lima puluh tiga"
            
        }
        if NumberInput.text == "154"
        {
            English.text = "one hundred and fifty four"
            Indonesian.text = "seratus lima puluh empat"
            
        }
        if NumberInput.text == "155"
        {
            English.text = "one hundred and fifty five"
            Indonesian.text = "seratus lima puluh lima"
            
        }
        if NumberInput.text == "156"
        {
            English.text = "one hundred and fifty six"
            Indonesian.text = "seratus lima puluh enam"
            
        }
        if NumberInput.text == "157"
        {
            English.text = "one hundred and fifty seven"
            Indonesian.text = "seratus lima puluh tujuh"
            
        }
        if NumberInput.text == "158"
        {
            English.text = "one hundred and fifty eight"
            Indonesian.text = "seratus lima puluh delapan"
            
        }
        if NumberInput.text == "159"
        {
            English.text = "one hundred and fifty nine"
            Indonesian.text = "seratus lima puluh sembilan"
            
        }
        if NumberInput.text == "160"
        {
            English.text = "one hundred and sixty"
            Indonesian.text = "seratus enam puluh"
            
        }
        if NumberInput.text == "161"
        {
            English.text = "one hundred and sixty one"
            Indonesian.text = "seratus enam puluh satu"
            
        }
        if NumberInput.text == "162"
        {
            English.text = "one hundred and sixty two"
            Indonesian.text = "seratus enam puluh dua"
            
        }
        if NumberInput.text == "163"
        {
            English.text = "one hundred and sixty three"
            Indonesian.text = "seratus enam puluh tiga"
            
        }
        if NumberInput.text == "164"
        {
            English.text = "one hundred and sixty four"
            Indonesian.text = "seratus enam puluh empat"
            
        }
        if NumberInput.text == "165"
        {
            English.text = "one hundred and sixty five"
            Indonesian.text = "seratus enam puluh lima"
            
        }
        if NumberInput.text == "166"
        {
            English.text = "one hundred and sixty six"
            Indonesian.text = "seratus enam puluh enam"
            
        }
        if NumberInput.text == "167"
        {
            English.text = "one hundred and sixty seven"
            Indonesian.text = "seratus enam puluh tujuh"
            
        }
        if NumberInput.text == "168"
        {
            English.text = "one hundred and sixty eight"
            Indonesian.text = "seratus enam puluh delapan"
            
        }
        if NumberInput.text == "169"
        {
            English.text = "one hundred and sixty nine"
            Indonesian.text = "seratus enam puluh sembilan"
            
        }
        if NumberInput.text == "170"
        {
            English.text = "one hundred and seventy"
            Indonesian.text = "seratus tujuh puluh"
            
        }
        if NumberInput.text == "171"
        {
            English.text = "one hundred and seventy one"
            Indonesian.text = "seratus tujuh puluh satu"
            
        }
        if NumberInput.text == "172"
        {
            English.text = "one hundred and seventy two"
            Indonesian.text = "seratus tujuh puluh dua"
            
        }
        if NumberInput.text == "173"
        {
            English.text = "one hundred and seventy three"
            Indonesian.text = "seratus tujuh puluh tiga"
            
        }
        if NumberInput.text == "174"
        {
            English.text = "one hundred and seventy four"
            Indonesian.text = "seratus tujuh puluh empat"
            
        }
        if NumberInput.text == "175"
        {
            English.text = "one hundred and seventy five"
            Indonesian.text = "seratus tujuh puluh lima"
            
        }
        if NumberInput.text == "176"
        {
            English.text = "one hundred and seventy six"
            Indonesian.text = "seratus tujuh puluh enam"
            
        }
        if NumberInput.text == "177"
        {
            English.text = "one hundred and seventy seven"
            Indonesian.text = "seratus tujuh puluh tujuh"
            
        }
        if NumberInput.text == "178"
        {
            English.text = "one hundred and seventy eight"
            Indonesian.text = "seratus tujuh puluh delapan"
            
        }
        if NumberInput.text == "179"
        {
            English.text = "one hundred and seventy nine"
            Indonesian.text = "seratus tujuh puluh sembilan"
            
        }
        if NumberInput.text == "180"
        {
            English.text = "one hundred and eighty"
            Indonesian.text = "seratus delapan puluh"
            
        }
        if NumberInput.text == "181"
        {
            English.text = "one hundred and eighty one"
            Indonesian.text = "seratus delapan puluh satu"
            
        }
        if NumberInput.text == "182"
        {
            English.text = "one hundred and eighty two"
            Indonesian.text = "seratus delapan puluh dua"
            
        }
        if NumberInput.text == "183"
        {
            English.text = "one hundred and eighty three"
            Indonesian.text = "seratus delapan puluh tiga"
            
        }
        if NumberInput.text == "184"
        {
            English.text = "one hundred and eighty four"
            Indonesian.text = "seratus delapan puluh empat"
            
        }
        if NumberInput.text == "185"
        {
            English.text = "one hundred and eighty five"
            Indonesian.text = "seratus delapan puluh lima"
            
        }
        if NumberInput.text == "186"
        {
            English.text = "one hundred and eighty six"
            Indonesian.text = "seratus delapan puluh enam"
            
        }
        if NumberInput.text == "187"
        {
            English.text = "one hundred and eighty seven"
            Indonesian.text = "seratus delapan puluh tujuh"
            
        }
        if NumberInput.text == "188"
        {
            English.text = "one hundred and eighty eight"
            Indonesian.text = "seratus delapan puluh delapan"
            
        }
        if NumberInput.text == "189"
        {
            English.text = "one hundred and eighty nine"
            Indonesian.text = "seratus delapan puluh sembilan"
            
        }
        if NumberInput.text == "190"
        {
            English.text = "one hundred and ninety"
            Indonesian.text = "sseratus embilan puluh"
            
        }
        if NumberInput.text == "191"
        {
            English.text = "one hundred and ninety one"
            Indonesian.text = "seratus sembilan puluh satu"
            
        }
        if NumberInput.text == "192"
        {
            English.text = "one hundred and ninety two"
            Indonesian.text = "seratus sembilan puluh dua"
            
        }
        if NumberInput.text == "193"
        {
            English.text = "one hundred and ninety three"
            Indonesian.text = "seratus sembilan puluh tiga"
            
        }
        if NumberInput.text == "194"
        {
            English.text = "one hundred and ninety four"
            Indonesian.text = "seratus sembilan puluh empat"
            
        }
        if NumberInput.text == "195"
        {
            English.text = "one hundred and ninety five"
            Indonesian.text = "seratus sembilan puluh lima"
            
        }
        if NumberInput.text == "196"
        {
            English.text = "one hundred and ninety six"
            Indonesian.text = "seratus sembilan puluh enam"
            
        }
        if NumberInput.text == "197"
        {
            English.text = "one hundred and ninety seven"
            Indonesian.text = "seratus sembilan puluh tujuh"
            
        }
        if NumberInput.text == "198"
        {
            English.text = "one hundred and ninety eight"
            Indonesian.text = "seratus sembilan puluh delapan"
            
        }
        if NumberInput.text == "199"
        {
            English.text = "one hundred and ninety nine"
            Indonesian.text = "seratus sembilan puluh sembilan"
            
        }
        if NumberInput.text == "200"
        {
            English.text = "two hundred"
            Indonesian.text = "dua ratus"
            
        }
        if NumberInput.text == "201"
        {
            English.text = "two hundred and one"
            Indonesian.text = "dua ratus satu"
            
        }
        if NumberInput.text == "202"
        {
            English.text = "two hundred and two"
            Indonesian.text = "dua ratus dua"
            
        }
        if NumberInput.text == "203"
        {
            English.text = "two hundred and three"
            Indonesian.text = "dua ratus tiga"
            
        }
        if NumberInput.text == "204"
        {
            English.text = "two hundred and four"
            Indonesian.text = "dua ratus empat"
            
        }
        if NumberInput.text == "205"
        {
            English.text = "two hundred and five"
            Indonesian.text = "dua ratus lima"
            
        }
        if NumberInput.text == "206"
        {
            English.text = "two hundred and six"
            Indonesian.text = "dua ratus enam"
            
        }
        if NumberInput.text == "207"
        {
            English.text = "two hundred and seven"
            Indonesian.text = "dua ratus tujuh"
            
        }
        if NumberInput.text == "208"
        {
            English.text = "two hundred and eight"
            Indonesian.text = "dua ratus delapan"
            
        }
        if NumberInput.text == "209"
        {
            English.text = "two hundred and nine"
            Indonesian.text = "dua ratus sembilan"
            
        }
        if NumberInput.text == "210"
        {
            English.text = "two hundred and ten"
            Indonesian.text = "dua ratus sepuluh"
            
        }
        if NumberInput.text == "211"
        {
            English.text = "two hundred and eleven"
            Indonesian.text = "dua ratus sebelas"
            
        }
        if NumberInput.text == "212"
        {
            English.text = "two hundred and twelve"
            Indonesian.text = "dua ratus dua belas"
            
        }
        if NumberInput.text == "213"
        {
            English.text = "two hundred and thirteen"
            Indonesian.text = "dua ratus tiga belas"
            
        }
        if NumberInput.text == "214"
        {
            English.text = "two hundred and fourteen"
            Indonesian.text = "dua ratus empat belas"
            
        }
        if NumberInput.text == "215"
        {
            English.text = "two hundred and fifteen"
            Indonesian.text = "dua ratus lima belas"
            
        }
        if NumberInput.text == "216"
        {
            English.text = "two hundred and sixteen"
            Indonesian.text = "dua ratus enam belas"
            
        }
        if NumberInput.text == "217"
        {
            English.text = "two hundred and seventeen"
            Indonesian.text = "dua ratus tujuh belas"
            
        }
        if NumberInput.text == "218"
        {
            English.text = "two hundred and eighteen"
            Indonesian.text = "dua ratus delapan belas"
            
        }
        if NumberInput.text == "219"
        {
            English.text = "two hundred and nineteen"
            Indonesian.text = "dua ratus sembilan belas"
            
        }
        if NumberInput.text == "220"
        {
            English.text = "two hundred and twenty"
            Indonesian.text = "dua ratus dua puluh"
            
        }
        if NumberInput.text == "221"
        {
            English.text = "two hundred and twenty one"
            Indonesian.text = "dua ratus dua puluh satu"
            
        }
        if NumberInput.text == "222"
        {
            English.text = "two hundred and twenty two"
            Indonesian.text = "dua ratus dua puluh dua"
            
        }
        if NumberInput.text == "223"
        {
            English.text = "two hundred and twenty three"
            Indonesian.text = "dua ratus dua puluh tiga"
            
        }
        if NumberInput.text == "224"
        {
            English.text = "two hundred and twenty four"
            Indonesian.text = "dua ratus dua puluh empat"
            
        }
        if NumberInput.text == "225"
        {
            English.text = "two hundred and twenty five"
            Indonesian.text = "dua ratus dua puluh lima"
            
        }
        if NumberInput.text == "226"
        {
            English.text = "two hundred and twenty six"
            Indonesian.text = "dua ratus dua puluh enam"
            
        }
        if NumberInput.text == "227"
        {
            English.text = "two hundred and twenty seven"
            Indonesian.text = "dua ratus dua puluh tujuh"
            
        }
        if NumberInput.text == "228"
        {
            English.text = "two hundred and twenty eight"
            Indonesian.text = "dua ratus dua puluh delapan"
            
        }
        if NumberInput.text == "229"
        {
            English.text = "two hundred and twenty nine"
            Indonesian.text = "dua ratus dua puluh sembilan"
            
        }
        if NumberInput.text == "230"
        {
            English.text = "two hundred and thirty"
            Indonesian.text = "dua ratus tiga puluh"
            
        }
        if NumberInput.text == "231"
        {
            English.text = "two hundred and thirty one"
            Indonesian.text = "dua ratus satu"
            
        }
        if NumberInput.text == "232"
        {
            English.text = "two hundred and thirty two"
            Indonesian.text = "dua ratus tiga puluh dua"
            
        }
        if NumberInput.text == "233"
        {
            English.text = "two hundred and thirty three"
            Indonesian.text = "dua ratus tiga puluh tiga"
            
        }
        if NumberInput.text == "234"
        {
            English.text = "two hundred and thirty four"
            Indonesian.text = "dua ratus tiga puluh empat"
            
        }
        if NumberInput.text == "235"
        {
            English.text = "two hundred and thirty five"
            Indonesian.text = "dua ratus tiga puluh lima"
            
        }
        if NumberInput.text == "236"
        {
            English.text = "two hundred and thirty six"
            Indonesian.text = "dua ratus tiga puluh enam"
            
        }
        if NumberInput.text == "237"
        {
            English.text = "two hundred and thirty seven"
            Indonesian.text = "dua ratus tiga puluh tujuh"
            
        }
        if NumberInput.text == "238"
        {
            English.text = "two hundred and thirty eight"
            Indonesian.text = "dua ratus tiga puluh delapan"
            
        }
        if NumberInput.text == "239"
        {
            English.text = "two hundred and thirty nine"
            Indonesian.text = "dua ratus tiga puluh sembilan"
            
        }
        if NumberInput.text == "240"
        {
            English.text = "two hundred and forty"
            Indonesian.text = "edua ratus mpat puluh"
            
        }
        if NumberInput.text == "241"
        {
            English.text = "two hundred and forty one"
            Indonesian.text = "dua ratus empat puluh satu"
            
        }
        if NumberInput.text == "242"
        {
            English.text = "two hundred and forty two"
            Indonesian.text = "dua ratus empat puluh dua"
            
        }
        if NumberInput.text == "243"
        {
            English.text = "two hundred and forty three"
            Indonesian.text = "dua ratus empat puluh tiga"
            
        }
        if NumberInput.text == "244"
        {
            English.text = "two hundred and forty four"
            Indonesian.text = "dua ratus empat puluh empat"
            
        }
        if NumberInput.text == "245"
        {
            English.text = "two hundred and forty five"
            Indonesian.text = "dua ratus empat puluh lima"
            
        }
        if NumberInput.text == "246"
        {
            English.text = "two hundred and forty six"
            Indonesian.text = "dua ratus empat puluh enam"
            
        }
        if NumberInput.text == "247"
        {
            English.text = "two hundred and forty seven"
            Indonesian.text = "dua ratus empat puluh tujuh"
            
        }
        if NumberInput.text == "248"
        {
            English.text = "two hundred and forty eight"
            Indonesian.text = "dua ratus empat puluh delapan"
            
        }
        if NumberInput.text == "249"
        {
            English.text = "two hundred and forty nine"
            Indonesian.text = "dua ratus empat puluh sembilan"
            
        }
        if NumberInput.text == "250"
        {
            English.text = "two hundred and fifty"
            Indonesian.text = "dua ratus lima puluh"
            
        }
        if NumberInput.text == "251"
        {
            English.text = "two hundred and fifty one"
            Indonesian.text = "dua ratus lima puluh satu"
            
        }
        if NumberInput.text == "252"
        {
            English.text = "two hundred and fifty two"
            Indonesian.text = "dua ratus lima puluh dua"
            
        }
        if NumberInput.text == "253"
        {
            English.text = "two hundred and fifty three"
            Indonesian.text = "dua ratus lima puluh tiga"
            
        }
        if NumberInput.text == "254"
        {
            English.text = "two hundred and fifty four"
            Indonesian.text = "dua ratus lima puluh empat"
            
        }
        if NumberInput.text == "255"
        {
            English.text = "two hundred and fifty five"
            Indonesian.text = "dua ratus lima puluh lima"
            
        }
        if NumberInput.text == "256"
        {
            English.text = "two hundred and fifty six"
            Indonesian.text = "dua ratus lima puluh enam"
            
        }
        if NumberInput.text == "257"
        {
            English.text = "two hundred and fifty seven"
            Indonesian.text = "dua ratus lima puluh tujuh"
            
        }
        if NumberInput.text == "258"
        {
            English.text = "two hundred and fifty eight"
            Indonesian.text = "dua ratus lima puluh delapan"
            
        }
        if NumberInput.text == "259"
        {
            English.text = "two hundred and fifty nine"
            Indonesian.text = "dua ratus lima puluh sembilan"
            
        }
        if NumberInput.text == "260"
        {
            English.text = "two hundred and sixty"
            Indonesian.text = "dua ratus enam puluh"
            
        }
        if NumberInput.text == "261"
        {
            English.text = "two hundred and sixty one"
            Indonesian.text = "dua ratus enam puluh satu"
            
        }
        if NumberInput.text == "262"
        {
            English.text = "two hundred and sixty two"
            Indonesian.text = "dua ratus enam puluh dua"
            
        }
        if NumberInput.text == "263"
        {
            English.text = "two hundred and sixty three"
            Indonesian.text = "dua ratus enam puluh tiga"
            
        }
        if NumberInput.text == "264"
        {
            English.text = "two hundred and sixty four"
            Indonesian.text = "dua ratus enam puluh empat"
            
        }
        if NumberInput.text == "265"
        {
            English.text = "two hundred and sixty five"
            Indonesian.text = "dua ratus enam puluh lima"
            
        }
        if NumberInput.text == "266"
        {
            English.text = "two hundred and sixty six"
            Indonesian.text = "dua ratus enam puluh enam"
            
        }
        if NumberInput.text == "267"
        {
            English.text = "two hundred and sixty seven"
            Indonesian.text = "dua ratus enam puluh tujuh"
            
        }
        if NumberInput.text == "268"
        {
            English.text = "two hundred and sixty eight"
            Indonesian.text = "dua ratus enam puluh delapan"
            
        }
        if NumberInput.text == "269"
        {
            English.text = "two hundred and sixty nine"
            Indonesian.text = "dua ratus enam puluh sembilan"
            
        }
        if NumberInput.text == "270"
        {
            English.text = "two hundred and seventy"
            Indonesian.text = "dua ratus tujuh puluh"
            
        }
        if NumberInput.text == "271"
        {
            English.text = "two hundred and seventy one"
            Indonesian.text = "dua ratus tujuh puluh satu"
            
        }
        if NumberInput.text == "272"
        {
            English.text = "two hundred and seventy two"
            Indonesian.text = "dua ratus tujuh puluh dua"
            
        }
        if NumberInput.text == "273"
        {
            English.text = "two hundred and seventy three"
            Indonesian.text = "dua ratus tujuh puluh tiga"
            
        }
        if NumberInput.text == "274"
        {
            English.text = "two hundred and seventy four"
            Indonesian.text = "dua ratus tujuh puluh empat"
            
        }
        if NumberInput.text == "275"
        {
            English.text = "two hundred and seventy five"
            Indonesian.text = "dua ratus tujuh puluh lima"
            
        }
        if NumberInput.text == "276"
        {
            English.text = "two hundred and seventy six"
            Indonesian.text = "dua ratus tujuh puluh enam"
            
        }
        if NumberInput.text == "277"
        {
            English.text = "two hundred and seventy seven"
            Indonesian.text = "dua ratus tujuh puluh tujuh"
            
        }
        if NumberInput.text == "278"
        {
            English.text = "two hundred and seventy eight"
            Indonesian.text = "dua ratus tujuh puluh delapan"
            
        }
        if NumberInput.text == "279"
        {
            English.text = "two hundred and seventy nine"
            Indonesian.text = "dua ratus tujuh puluh sembilan"
            
        }
        if NumberInput.text == "280"
        {
            English.text = "two hundred and eighty"
            Indonesian.text = "dua ratus delapan puluh"
            
        }
        if NumberInput.text == "281"
        {
            English.text = "two hundred and eighty one"
            Indonesian.text = "dua ratus delapan puluh satu"
            
        }
        if NumberInput.text == "282"
        {
            English.text = "two hundred and eighty two"
            Indonesian.text = "dua ratus delapan puluh dua"
            
        }
        if NumberInput.text == "283"
        {
            English.text = "two hundred and eighty three"
            Indonesian.text = "dua ratus delapan puluh tiga"
            
        }
        if NumberInput.text == "284"
        {
            English.text = "two hundred and eighty four"
            Indonesian.text = "dua ratus delapan puluh empat"
            
        }
        if NumberInput.text == "285"
        {
            English.text = "two hundred and eighty five"
            Indonesian.text = "dua ratus delapan puluh lima"
            
        }
        if NumberInput.text == "286"
        {
            English.text = "dua ratus two hundred and eighty six"
            Indonesian.text = "delapan puluh enam"
            
        }
        if NumberInput.text == "287"
        {
            English.text = "two hundred and eighty seven"
            Indonesian.text = "dua ratus delapan puluh tujuh"
            
        }
        if NumberInput.text == "288"
        {
            English.text = "two hundred and eighty eight"
            Indonesian.text = "dua ratus delapan puluh delapan"
            
        }
        if NumberInput.text == "289"
        {
            English.text = "two hundred and eighty nine"
            Indonesian.text = "dua ratus delapan puluh sembilan"
            
        }
        if NumberInput.text == "290"
        {
            English.text = "two hundred and ninety"
            Indonesian.text = "dua ratus sembilan puluh"
            
        }
        if NumberInput.text == "291"
        {
            English.text = "two hundred and ninety one"
            Indonesian.text = "dua ratus sembilan puluh satu"
            
        }
        if NumberInput.text == "292"
        {
            English.text = "two hundred and ninety two"
            Indonesian.text = "sdua ratus embilan puluh dua"
            
        }
        if NumberInput.text == "293"
        {
            English.text = "two hundred and ninety three"
            Indonesian.text = "dua ratus sembilan puluh tiga"
            
        }
        if NumberInput.text == "294"
        {
            English.text = "two hundred and ninety four"
            Indonesian.text = "dua ratus sembilan puluh empat"
            
        }
        if NumberInput.text == "295"
        {
            English.text = "two hundred and ninety five"
            Indonesian.text = "dua ratus sembilan puluh lima"
            
        }
        if NumberInput.text == "296"
        {
            English.text = "two hundred and ninety six"
            Indonesian.text = "dua ratus sembilan puluh enam"
            
        }
        if NumberInput.text == "297"
        {
            English.text = "two hundred and ninety seven"
            Indonesian.text = "dua ratus sembilan puluh tujuh"
            
        }
        if NumberInput.text == "298"
        {
            English.text = "two hundred and ninety eight"
            Indonesian.text = "dua ratus sembilan puluh delapan"
            
        }
        if NumberInput.text == "299"
        {
            English.text = "two hundred and ninety nine"
            Indonesian.text = "dua ratus sembilan puluh sembilan"
            
        }
        if NumberInput.text == "300"
        {
            English.text = "three hundred"
            Indonesian.text = "tiga ratus"
            
        }
        if NumberInput.text == "301"
        {
            English.text = "three hundred and one"
            Indonesian.text = "tiga ratus satu"
            
        }
        if NumberInput.text == "302"
        {
            English.text = "three hundred and two"
            Indonesian.text = "tiga ratus dua"
            
        }
        if NumberInput.text == "303"
        {
            English.text = "three hundred and three"
            Indonesian.text = "tiga ratus tiga"
            
        }
        if NumberInput.text == "304"
        {
            English.text = "three hundred and four"
            Indonesian.text = "tiga ratus empat"
            
        }
        if NumberInput.text == "305"
        {
            English.text = "three hundred and five"
            Indonesian.text = "tiga ratus lima"
            
        }
        if NumberInput.text == "306"
        {
            English.text = "three hundred and six"
            Indonesian.text = "tiga ratus enam"
            
        }
        if NumberInput.text == "307"
        {
            English.text = "three hundred and seven"
            Indonesian.text = "tiga ratus tujuh"
            
        }
        if NumberInput.text == "308"
        {
            English.text = "three hundred and eight"
            Indonesian.text = "tiga ratus delapan"
            
        }
        if NumberInput.text == "309"
        {
            English.text = "three hundred and nine"
            Indonesian.text = "tiga ratus sembilan"
            
        }
        if NumberInput.text == "310"
        {
            English.text = "three hundred and ten"
            Indonesian.text = "tiga ratus sepuluh"
            
        }
        if NumberInput.text == "311"
        {
            English.text = "three hundred and eleven"
            Indonesian.text = "tiga ratus sebelas"
            
        }
        if NumberInput.text == "312"
        {
            English.text = "three hundred and twelve"
            Indonesian.text = "tiga ratus dua belas"
            
        }
        if NumberInput.text == "313"
        {
            English.text = "three hundred and thirteen"
            Indonesian.text = "tiga ratus tiga belas"
            
        }
        if NumberInput.text == "314"
        {
            English.text = "three hundred and fourteen"
            Indonesian.text = "tiga ratus empat belas"
            
        }
        if NumberInput.text == "315"
        {
            English.text = "three hundred and fifteen"
            Indonesian.text = "tiga ratus lima belas"
            
        }
        if NumberInput.text == "316"
        {
            English.text = "three hundred and sixteen"
            Indonesian.text = "tiga ratus enam belas"
            
        }
        if NumberInput.text == "317"
        {
            English.text = "three hundred and seventeen"
            Indonesian.text = "tiga ratus tujuh belas"
            
        }
        if NumberInput.text == "318"
        {
            English.text = "three hundred and eighteen"
            Indonesian.text = "tiga ratus delapan belas"
            
        }
        if NumberInput.text == "319"
        {
            English.text = "three hundred and nineteen"
            Indonesian.text = "tiga ratus sembilan belas"
            
        }
        if NumberInput.text == "320"
        {
            English.text = "three hundred and twenty"
            Indonesian.text = "tiga ratus dua puluh"
            
        }
        if NumberInput.text == "321"
        {
            English.text = "three hundred and twenty one"
            Indonesian.text = "tiga ratus dua puluh satu"
            
        }
        if NumberInput.text == "322"
        {
            English.text = "three hundred and twenty two"
            Indonesian.text = "tiga ratus dua puluh dua"
            
        }
        if NumberInput.text == "323"
        {
            English.text = "three hundred and twenty three"
            Indonesian.text = "tiga ratus dua puluh tiga"
            
        }
        if NumberInput.text == "324"
        {
            English.text = "three hundred and twenty four"
            Indonesian.text = "tiga ratus dua puluh empat"
            
        }
        if NumberInput.text == "325"
        {
            English.text = "three hundred and twenty five"
            Indonesian.text = "tiga ratus dua puluh lima"
            
        }
        if NumberInput.text == "326"
        {
            English.text = "three hundred and twenty six"
            Indonesian.text = "tiga ratus dua puluh enam"
            
        }
        if NumberInput.text == "327"
        {
            English.text = "three hundred and twenty seven"
            Indonesian.text = "tiga ratus dua puluh tujuh"
            
        }
        if NumberInput.text == "328"
        {
            English.text = "three hundred and twenty eight"
            Indonesian.text = "tiga ratus dua puluh delapan"
            
        }
        if NumberInput.text == "329"
        {
            English.text = "three hundred and twenty nine"
            Indonesian.text = "tiga ratus dua puluh sembilan"
            
        }
        if NumberInput.text == "330"
        {
            English.text = "three hundred and thirty"
            Indonesian.text = "tiga ratus tiga puluh"
            
        }
        if NumberInput.text == "331"
        {
            English.text = "three hundred and thirty one"
            Indonesian.text = "tiga ratus tiga puluh satu"
            
        }
        if NumberInput.text == "332"
        {
            English.text = "three hundred and thirty two"
            Indonesian.text = "tiga ratus tiga puluh dua"
            
        }
        if NumberInput.text == "333"
        {
            English.text = "three hundred and thirty three"
            Indonesian.text = "tiga ratus tiga puluh tiga"
            
        }
        if NumberInput.text == "334"
        {
            English.text = "three hundred and thirty four"
            Indonesian.text = "tiga ratus tiga puluh empat"
            
        }
        if NumberInput.text == "335"
        {
            English.text = "three hundred and thirty five"
            Indonesian.text = "tiga ratus tiga puluh lima"
            
        }
        if NumberInput.text == "336"
        {
            English.text = "three hundred and thirty six"
            Indonesian.text = "tiga ratus tiga puluh enam"
            
        }
        if NumberInput.text == "337"
        {
            English.text = "three hundred and thirty seven"
            Indonesian.text = "tiga ratus tiga puluh tujuh"
            
        }
        if NumberInput.text == "338"
        {
            English.text = "three hundred and thirty eight"
            Indonesian.text = "tiga ratus tiga puluh delapan"
            
        }
        if NumberInput.text == "339"
        {
            English.text = "three hundred and thirty nine"
            Indonesian.text = "tiga ratus tiga puluh sembilan"
            
        }
        if NumberInput.text == "340"
        {
            English.text = "three hundred and forty"
            Indonesian.text = "tiga ratus empat puluh"
            
        }
        if NumberInput.text == "341"
        {
            English.text = "three hundred and forty one"
            Indonesian.text = "tiga ratus empat puluh satu"
            
        }
        if NumberInput.text == "342"
        {
            English.text = "three hundred and forty two"
            Indonesian.text = "tiga ratus empat puluh dua"
            
        }
        if NumberInput.text == "343"
        {
            English.text = "three hundred and forty three"
            Indonesian.text = "tiga ratus empat puluh tiga"
            
        }
        if NumberInput.text == "344"
        {
            English.text = "three hundred and forty four"
            Indonesian.text = "tiga ratus empat puluh empat"
            
        }
        if NumberInput.text == "345"
        {
            English.text = "three hundred and forty five"
            Indonesian.text = "tiga ratus empat puluh lima"
            
        }
        if NumberInput.text == "346"
        {
            English.text = "three hundred and forty six"
            Indonesian.text = "tiga ratus empat puluh enam"
            
        }
        if NumberInput.text == "347"
        {
            English.text = "three hundred and forty seven"
            Indonesian.text = "tiga ratus empat puluh tujuh"
            
        }
        if NumberInput.text == "348"
        {
            English.text = "three hundred and forty eight"
            Indonesian.text = "tiga ratus empat puluh delapan"
            
        }
        if NumberInput.text == "349"
        {
            English.text = "three hundred and forty nine"
            Indonesian.text = "tiga ratus empat puluh sembilan"
            
        }
        if NumberInput.text == "350"
        {
            English.text = "three hundred and fifty"
            Indonesian.text = "tiga ratus lima puluh"
            
        }
        if NumberInput.text == "351"
        {
            English.text = "three hundred and fifty one"
            Indonesian.text = "tiga ratus lima puluh satu"
            
        }
        if NumberInput.text == "352"
        {
            English.text = "three hundred and fifty two"
            Indonesian.text = "tiga ratus lima puluh dua"
            
        }
        if NumberInput.text == "353"
        {
            English.text = "three hundred and fifty three"
            Indonesian.text = "tiga ratus lima puluh tiga"
            
        }
        if NumberInput.text == "354"
        {
            English.text = "three hundred and fifty four"
            Indonesian.text = "tiga ratus lima puluh empat"
            
        }
        if NumberInput.text == "355"
        {
            English.text = "three hundred and fifty five"
            Indonesian.text = "tiga ratus lima puluh lima"
            
        }
        if NumberInput.text == "356"
        {
            English.text = "three hundred and fifty six"
            Indonesian.text = "tiga ratus lima puluh enam"
            
        }
        if NumberInput.text == "357"
        {
            English.text = "three hundred and fifty seven"
            Indonesian.text = "tiga ratus lima puluh tujuh"
            
        }
        if NumberInput.text == "358"
        {
            English.text = "three hundred and fifty eight"
            Indonesian.text = "tiga ratus lima puluh delapan"
            
        }
        if NumberInput.text == "359"
        {
            English.text = "three hundred and fifty nine"
            Indonesian.text = "tiga ratus lima puluh sembilan"
            
        }
        if NumberInput.text == "360"
        {
            English.text = "three hundred and sixty"
            Indonesian.text = "tiga ratus enam puluh"
            
        }
        if NumberInput.text == "361"
        {
            English.text = "three hundred and sixty one"
            Indonesian.text = "tiga ratus enam puluh satu"
            
        }
        if NumberInput.text == "362"
        {
            English.text = "three hundred and sixty two"
            Indonesian.text = "tiga ratus enam puluh dua"
            
        }
        if NumberInput.text == "363"
        {
            English.text = "three hundred and sixty three"
            Indonesian.text = "tiga ratus enam puluh tiga"
            
        }
        if NumberInput.text == "364"
        {
            English.text = "three hundred and sixty four"
            Indonesian.text = "tiga ratus enam puluh empat"
            
        }
        if NumberInput.text == "365"
        {
            English.text = "three hundred and sixty five"
            Indonesian.text = "tiga ratus enam puluh lima"
            
        }
        if NumberInput.text == "366"
        {
            English.text = "three hundred and sixty six"
            Indonesian.text = "tiga ratus enam puluh enam"
            
        }
        if NumberInput.text == "367"
        {
            English.text = "three hundred and sixty seven"
            Indonesian.text = "tiga ratus enam puluh tujuh"
            
        }
        if NumberInput.text == "368"
        {
            English.text = "three hundred and sixty eight"
            Indonesian.text = "tiga ratus enam puluh delapan"
            
        }
        if NumberInput.text == "369"
        {
            English.text = "three hundred and sixty nine"
            Indonesian.text = "tiga ratus enam puluh sembilan"
            
        }
        if NumberInput.text == "370"
        {
            English.text = "three hundred and seventy"
            Indonesian.text = "tiga ratus tujuh puluh"
            
        }
        if NumberInput.text == "371"
        {
            English.text = "three hundred and seventy one"
            Indonesian.text = "tiga ratus tujuh puluh satu"
            
        }
        if NumberInput.text == "372"
        {
            English.text = "three hundred and seventy two"
            Indonesian.text = "tiga ratus tujuh puluh dua"
            
        }
        if NumberInput.text == "373"
        {
            English.text = "three hundred and seventy three"
            Indonesian.text = "tiga ratus tujuh puluh tiga"
            
        }
        if NumberInput.text == "374"
        {
            English.text = "three hundred and seventy four"
            Indonesian.text = "tiga ratus tujuh puluh empat"
            
        }
        if NumberInput.text == "375"
        {
            English.text = "three hundred and seventy five"
            Indonesian.text = "tiga ratus tujuh puluh lima"
            
        }
        if NumberInput.text == "376"
        {
            English.text = "three hundred and seventy six"
            Indonesian.text = "tiga ratus tujuh puluh enam"
            
        }
        if NumberInput.text == "377"
        {
            English.text = "three hundred and seventy seven"
            Indonesian.text = "tiga ratus tujuh puluh tujuh"
            
        }
        if NumberInput.text == "378"
        {
            English.text = "three hundred and seventy eight"
            Indonesian.text = "tiga ratus tujuh puluh delapan"
            
        }
        if NumberInput.text == "379"
        {
            English.text = "three hundred and seventy nine"
            Indonesian.text = "tiga ratus tujuh puluh sembilan"
            
        }
        if NumberInput.text == "380"
        {
            English.text = "three hundred and eighty"
            Indonesian.text = "tiga ratus delapan puluh"
            
        }
        if NumberInput.text == "381"
        {
            English.text = "three hundred and eighty one"
            Indonesian.text = "tiga ratus delapan puluh satu"
            
        }
        if NumberInput.text == "382"
        {
            English.text = "three hundred and eighty two"
            Indonesian.text = "tiga ratus delapan puluh dua"
            
        }
        if NumberInput.text == "383"
        {
            English.text = "three hundred and eighty three"
            Indonesian.text = "tiga ratus delapan puluh tiga"
            
        }
        if NumberInput.text == "384"
        {
            English.text = "three hundred and eighty four"
            Indonesian.text = "tiga ratus delapan puluh empat"
            
        }
        if NumberInput.text == "385"
        {
            English.text = "three hundred and eighty five"
            Indonesian.text = "tiga ratus delapan puluh lima"
            
        }
        if NumberInput.text == "386"
        {
            English.text = "three hundred and eighty six"
            Indonesian.text = "tiga ratus delapan puluh enam"
            
        }
        if NumberInput.text == "387"
        {
            English.text = "three hundred and eighty seven"
            Indonesian.text = "tiga ratus delapan puluh tujuh"
            
        }
        if NumberInput.text == "388"
        {
            English.text = "three hundred and eighty eight"
            Indonesian.text = "tiga ratus delapan puluh delapan"
            
        }
        if NumberInput.text == "389"
        {
            English.text = "three hundred and eighty nine"
            Indonesian.text = "tiga ratus delapan puluh sembilan"
            
        }
        if NumberInput.text == "390"
        {
            English.text = "three hundred and ninety"
            Indonesian.text = "tiga ratus sembilan puluh"
            
        }
        if NumberInput.text == "391"
        {
            English.text = "three hundred and ninety one"
            Indonesian.text = "tiga ratus sembilan puluh satu"
            
        }
        if NumberInput.text == "392"
        {
            English.text = "three hundred and ninety two"
            Indonesian.text = "tiga ratus sembilan puluh dua"
            
        }
        if NumberInput.text == "393"
        {
            English.text = "three hundred and ninety three"
            Indonesian.text = "tiga ratus sembilan puluh tiga"
            
        }
        if NumberInput.text == "394"
        {
            English.text = "three hundred and ninety four"
            Indonesian.text = "tiga ratus sembilan puluh empat"
            
        }
        if NumberInput.text == "395"
        {
            English.text = "three hundred and ninety five"
            Indonesian.text = "tiga ratus sembilan puluh lima"
            
        }
        if NumberInput.text == "396"
        {
            English.text = "three hundred and ninety six"
            Indonesian.text = "tiga ratus sembilan puluh enam"
            
        }
        if NumberInput.text == "397"
        {
            English.text = "three hundred and ninety seven"
            Indonesian.text = "tiga ratus sembilan puluh tujuh"
            
        }
        if NumberInput.text == "398"
        {
            English.text = "three hundred and ninety eight"
            Indonesian.text = "tiga ratus sembilan puluh delapan"
            
        }
        if NumberInput.text == "399"
        {
            English.text = "three hundred and ninety nine"
            Indonesian.text = "tiga ratus sembilan puluh sembilan"
            
        }
        if NumberInput.text == "400"
        {
            English.text = "four hundred"
            Indonesian.text = "empat ratus"
            
        }
        if NumberInput.text == "401"
        {
            English.text = "four hundred and one"
            Indonesian.text = "empat ratus satu"
            
        }
        if NumberInput.text == "402"
        {
            English.text = "four hundred and two"
            Indonesian.text = "empat ratus dua"
            
        }
        if NumberInput.text == "403"
        {
            English.text = "four hundred and three"
            Indonesian.text = "empat ratus tiga"
            
        }
        if NumberInput.text == "404"
        {
            English.text = "four hundred and four"
            Indonesian.text = "empat ratus empat"
            
        }
        if NumberInput.text == "405"
        {
            English.text = "four hundred and five"
            Indonesian.text = "empat ratus lima"
            
        }
        if NumberInput.text == "406"
        {
            English.text = "four hundred and six"
            Indonesian.text = "empat ratus enam"
            
        }
        if NumberInput.text == "407"
        {
            English.text = "four hundred and seven"
            Indonesian.text = "empat ratus tujuh"
            
        }
        if NumberInput.text == "408"
        {
            English.text = "four hundred and eight"
            Indonesian.text = "empat ratus delapan"
            
        }
        if NumberInput.text == "409"
        {
            English.text = "four hundred and nine"
            Indonesian.text = "empat ratus sembilan"
            
        }
        if NumberInput.text == "410"
        {
            English.text = "four hundred and ten"
            Indonesian.text = "empat ratus sepuluh"
            
        }
        if NumberInput.text == "411"
        {
            English.text = "four hundred and eleven"
            Indonesian.text = "empat ratus sebelas"
            
        }
        if NumberInput.text == "412"
        {
            English.text = "four hundred and twelve"
            Indonesian.text = "empat ratus dua belas"
            
        }
        if NumberInput.text == "413"
        {
            English.text = "four hundred and thirteen"
            Indonesian.text = "empat ratus tiga belas"
            
        }
        if NumberInput.text == "414"
        {
            English.text = "four hundred and fourteen"
            Indonesian.text = "empat ratus empat belas"
            
        }
        if NumberInput.text == "415"
        {
            English.text = "four hundred and fifteen"
            Indonesian.text = "empat ratus lima belas"
            
        }
        if NumberInput.text == "416"
        {
            English.text = "four hundred and sixteen"
            Indonesian.text = "empat ratus enam belas"
            
        }
        if NumberInput.text == "417"
        {
            English.text = "four hundred and seventeen"
            Indonesian.text = "empat ratus tujuh belas"
            
        }
        if NumberInput.text == "418"
        {
            English.text = "four hundred and eighteen"
            Indonesian.text = "empat ratus delapan belas"
            
        }
        if NumberInput.text == "419"
        {
            English.text = "four hundred and nineteen"
            Indonesian.text = "empat ratus sembilan belas"
            
        }
        if NumberInput.text == "420"
        {
            English.text = "four hundred and twenty"
            Indonesian.text = "empat ratus dua puluh"
            
        }
        if NumberInput.text == "421"
        {
            English.text = "four hundred and twenty one"
            Indonesian.text = "empat ratus dua puluh satu"
            
        }
        if NumberInput.text == "422"
        {
            English.text = "four hundred and twenty two"
            Indonesian.text = "empat ratus dua puluh dua"
            
        }
        if NumberInput.text == "423"
        {
            English.text = "four hundred and twenty three"
            Indonesian.text = "empat ratus dua puluh tiga"
            
        }
        if NumberInput.text == "424"
        {
            English.text = "four hundred and twenty four"
            Indonesian.text = "empat ratus dua puluh empat"
            
        }
        if NumberInput.text == "425"
        {
            English.text = "four hundred and twenty five"
            Indonesian.text = "empat ratus dua puluh lima"
            
        }
        if NumberInput.text == "426"
        {
            English.text = "four hundred and twenty six"
            Indonesian.text = "empat ratus dua puluh enam"
            
        }
        if NumberInput.text == "427"
        {
            English.text = "four hundred and twenty seven"
            Indonesian.text = "empat ratus dua puluh tujuh"
            
        }
        if NumberInput.text == "428"
        {
            English.text = "four hundred and twenty eight"
            Indonesian.text = "empat ratus dua puluh delapan"
            
        }
        if NumberInput.text == "429"
        {
            English.text = "four hundred and twenty nine"
            Indonesian.text = "empat ratus dua puluh sembilan"
            
        }
        if NumberInput.text == "430"
        {
            English.text = "four hundred and thirty"
            Indonesian.text = "empat ratus tiga puluh"
            
        }
        if NumberInput.text == "431"
        {
            English.text = "four hundred and thirty one"
            Indonesian.text = "empat ratus satu"
            
        }
        if NumberInput.text == "432"
        {
            English.text = "four hundred and thirty two"
            Indonesian.text = "empat ratus tiga puluh dua"
            
        }
        if NumberInput.text == "433"
        {
            English.text = "four hundred and thirty three"
            Indonesian.text = "empat ratus tiga puluh tiga"
            
        }
        if NumberInput.text == "434"
        {
            English.text = "four hundred and thirty four"
            Indonesian.text = "empat ratus tiga puluh empat"
            
        }
        if NumberInput.text == "435"
        {
            English.text = "four hundred and thirty five"
            Indonesian.text = "empat ratus tiga puluh lima"
            
        }
        if NumberInput.text == "436"
        {
            English.text = "four hundred and thirty six"
            Indonesian.text = "empat ratus tiga puluh enam"
            
        }
        if NumberInput.text == "437"
        {
            English.text = "four hundred and thirty seven"
            Indonesian.text = "empat ratus tiga puluh tujuh"
            
        }
        if NumberInput.text == "438"
        {
            English.text = "four hundred and thirty eight"
            Indonesian.text = "empat ratus tiga puluh delapan"
            
        }
        if NumberInput.text == "439"
        {
            English.text = "four hundred and thirty nine"
            Indonesian.text = "empat ratus tiga puluh sembilan"
            
        }
        if NumberInput.text == "440"
        {
            English.text = "four hundred and forty"
            Indonesian.text = "empat ratus empat puluh"
            
        }
        if NumberInput.text == "441"
        {
            English.text = "four hundred and forty one"
            Indonesian.text = "empat ratus empat puluh satu"
            
        }
        if NumberInput.text == "442"
        {
            English.text = "four hundred and forty two"
            Indonesian.text = "empat ratus empat puluh dua"
            
        }
        if NumberInput.text == "443"
        {
            English.text = "four hundred and forty three"
            Indonesian.text = "empat ratus empat puluh tiga"
            
        }
        if NumberInput.text == "444"
        {
            English.text = "four hundred and forty four"
            Indonesian.text = "empat ratus empat puluh empat"
            
        }
        if NumberInput.text == "445"
        {
            English.text = "four hundred and forty five"
            Indonesian.text = "empat ratus empat puluh lima"
            
        }
        if NumberInput.text == "446"
        {
            English.text = "four hundred and forty six"
            Indonesian.text = "empat ratus empat puluh enam"
            
        }
        if NumberInput.text == "447"
        {
            English.text = "four hundred and forty seven"
            Indonesian.text = "empat ratus empat puluh tujuh"
            
        }
        if NumberInput.text == "448"
        {
            English.text = "four hundred and forty eight"
            Indonesian.text = "empat ratus empat puluh delapan"
            
        }
        if NumberInput.text == "449"
        {
            English.text = "four hundred and forty nine"
            Indonesian.text = "empat ratus empat puluh sembilan"
            
        }
        if NumberInput.text == "450"
        {
            English.text = "four hundred and fifty"
            Indonesian.text = "empat ratus lima puluh"
            
        }
        if NumberInput.text == "451"
        {
            English.text = "four hundred and fifty one"
            Indonesian.text = "empat ratus lima puluh satu"
            
        }
        if NumberInput.text == "452"
        {
            English.text = "four hundred and fifty two"
            Indonesian.text = "empat ratus lima puluh dua"
            
        }
        if NumberInput.text == "453"
        {
            English.text = "four hundred and fifty three"
            Indonesian.text = "empat ratus lima puluh tiga"
            
        }
        if NumberInput.text == "454"
        {
            English.text = "four hundred and fifty four"
            Indonesian.text = "empat ratus lima puluh empat"
            
        }
        if NumberInput.text == "455"
        {
            English.text = "four hundred and fifty five"
            Indonesian.text = "empat ratus lima puluh lima"
            
        }
        if NumberInput.text == "456"
        {
            English.text = "four hundred and fifty six"
            Indonesian.text = "empat ratus lima puluh enam"
            
        }
        if NumberInput.text == "457"
        {
            English.text = "four hundred and fifty seven"
            Indonesian.text = "empat ratus lima puluh tujuh"
            
        }
        if NumberInput.text == "458"
        {
            English.text = "four hundred and fifty eight"
            Indonesian.text = "empat ratus lima puluh delapan"
            
        }
        if NumberInput.text == "459"
        {
            English.text = "four hundred and fifty nine"
            Indonesian.text = "empat ratus lima puluh sembilan"
            
        }
        if NumberInput.text == "460"
        {
            English.text = "four hundred and sixty"
            Indonesian.text = "empat ratus enam puluh"
            
        }
        if NumberInput.text == "461"
        {
            English.text = "four hundred and sixty one"
            Indonesian.text = "empat ratus enam puluh satu"
            
        }
        if NumberInput.text == "462"
        {
            English.text = "four hundred and sixty two"
            Indonesian.text = "empat ratus enam puluh dua"
            
        }
        if NumberInput.text == "463"
        {
            English.text = "four hundred and sixty three"
            Indonesian.text = "empat ratus enam puluh tiga"
            
        }
        if NumberInput.text == "464"
        {
            English.text = "four hundred and sixty four"
            Indonesian.text = "empat ratus enam puluh empat"
            
        }
        if NumberInput.text == "465"
        {
            English.text = "four hundred and sixty five"
            Indonesian.text = "empat ratus enam puluh lima"
            
        }
        if NumberInput.text == "466"
        {
            English.text = "four hundred and sixty six"
            Indonesian.text = "empat ratus enam puluh enam"
            
        }
        if NumberInput.text == "467"
        {
            English.text = "four hundred and sixty seven"
            Indonesian.text = "empat ratus enam puluh tujuh"
            
        }
        if NumberInput.text == "468"
        {
            English.text = "four hundred and sixty eight"
            Indonesian.text = "empat ratus enam puluh delapan"
            
        }
        if NumberInput.text == "469"
        {
            English.text = "four hundred and sixty nine"
            Indonesian.text = "empat ratus enam puluh sembilan"
            
        }
        if NumberInput.text == "470"
        {
            English.text = "four hundred and seventy"
            Indonesian.text = "empat ratus tujuh puluh"
            
        }
        if NumberInput.text == "471"
        {
            English.text = "four hundred and seventy one"
            Indonesian.text = "empat ratus tujuh puluh satu"
            
        }
        if NumberInput.text == "472"
        {
            English.text = "four hundred and seventy two"
            Indonesian.text = "empat ratus tujuh puluh dua"
            
        }
        if NumberInput.text == "473"
        {
            English.text = "four hundred and seventy three"
            Indonesian.text = "empat ratus tujuh puluh tiga"
            
        }
        if NumberInput.text == "474"
        {
            English.text = "four hundred and seventy four"
            Indonesian.text = "empat ratus tujuh puluh empat"
            
        }
        if NumberInput.text == "475"
        {
            English.text = "four hundred and seventy five"
            Indonesian.text = "empat ratus tujuh puluh lima"
            
        }
        if NumberInput.text == "476"
        {
            English.text = "four hundred and seventy six"
            Indonesian.text = "empat ratus tujuh puluh enam"
            
        }
        if NumberInput.text == "477"
        {
            English.text = "four hundred and seventy seven"
            Indonesian.text = "empat ratus tujuh puluh tujuh"
            
        }
        if NumberInput.text == "478"
        {
            English.text = "four hundred and seventy eight"
            Indonesian.text = "empat ratus tujuh puluh delapan"
            
        }
        if NumberInput.text == "479"
        {
            English.text = "four hundred and seventy nine"
            Indonesian.text = "empat ratus tujuh puluh sembilan"
            
        }
        if NumberInput.text == "480"
        {
            English.text = "four hundred and eighty"
            Indonesian.text = "empat ratus delapan puluh"
            
        }
        if NumberInput.text == "481"
        {
            English.text = "four hundred and eighty one"
            Indonesian.text = "empat ratus delapan puluh satu"
            
        }
        if NumberInput.text == "482"
        {
            English.text = "four hundred and eighty two"
            Indonesian.text = "empat ratus delapan puluh dua"
            
        }
        if NumberInput.text == "483"
        {
            English.text = "four hundred and eighty three"
            Indonesian.text = "empat ratus delapan puluh tiga"
            
        }
        if NumberInput.text == "484"
        {
            English.text = "four hundred and eighty four"
            Indonesian.text = "empat ratus delapan puluh empat"
            
        }
        if NumberInput.text == "485"
        {
            English.text = "four hundred and eighty five"
            Indonesian.text = "empat ratus delapan puluh lima"
            
        }
        if NumberInput.text == "486"
        {
            English.text = "four hundred and eighty six"
            Indonesian.text = "empat ratus delapan puluh enam"
            
        }
        if NumberInput.text == "487"
        {
            English.text = "four hundred and eighty seven"
            Indonesian.text = "empat ratus delapan puluh tujuh"
            
        }
        if NumberInput.text == "488"
        {
            English.text = "four hundred and eighty eight"
            Indonesian.text = "empat ratus delapan puluh delapan"
            
        }
        if NumberInput.text == "489"
        {
            English.text = "four hundred and eighty nine"
            Indonesian.text = "empat ratus delapan puluh sembilan"
            
        }
        if NumberInput.text == "490"
        {
            English.text = "four hundred and ninety"
            Indonesian.text = "empat ratus sembilan puluh"
            
        }
        if NumberInput.text == "491"
        {
            English.text = "four hundred and ninety one"
            Indonesian.text = "empat ratus sembilan puluh satu"
            
        }
        if NumberInput.text == "492"
        {
            English.text = "four hundred and ninety two"
            Indonesian.text = "empat ratus sembilan puluh dua"
            
        }
        if NumberInput.text == "493"
        {
            English.text = "four hundred and ninety three"
            Indonesian.text = "empat ratus sembilan puluh tiga"
            
        }
        if NumberInput.text == "494"
        {
            English.text = "four hundred and ninety four"
            Indonesian.text = "empat ratus sembilan puluh empat"
            
        }
        if NumberInput.text == "495"
        {
            English.text = "four hundred and ninety five"
            Indonesian.text = "empat ratus sembilan puluh lima"
            
        }
        if NumberInput.text == "496"
        {
            English.text = "four hundred and ninety six"
            Indonesian.text = "empat ratus sembilan puluh enam"
            
        }
        if NumberInput.text == "497"
        {
            English.text = "four hundred and ninety seven"
            Indonesian.text = "empat ratus sembilan puluh tujuh"
            
        }
        if NumberInput.text == "498"
        {
            English.text = "four hundred and ninety eight"
            Indonesian.text = "empat ratus sembilan puluh delapan"
            
        }
        if NumberInput.text == "499"
        {
            English.text = "four hundred and ninety nine"
            Indonesian.text = "empat ratus sembilan puluh sembilan"
            
        }
        if NumberInput.text == "500"
        {
            English.text = "five hundred"
            Indonesian.text = "lima ratus"
            
        }
        if NumberInput.text == "500"
        {
            English.text = "five hundred"
            Indonesian.text = "lima ratus"
            
        }
        if NumberInput.text == "501"
        {
            English.text = "five hundred and one"
            Indonesian.text = "lima ratus satu"
            
        }
        if NumberInput.text == "502"
        {
            English.text = "five hundred and two"
            Indonesian.text = "lima ratus dua"
            
        }
        if NumberInput.text == "503"
        {
            English.text = "five hundred and three"
            Indonesian.text = "lima ratus tiga"
            
        }
        if NumberInput.text == "504"
        {
            English.text = "five hundred and four"
            Indonesian.text = "lima ratus empat"
            
        }
        if NumberInput.text == "505"
        {
            English.text = "five hundred and five"
            Indonesian.text = "lima ratus lima"
            
        }
        if NumberInput.text == "506"
        {
            English.text = "five hundred and six"
            Indonesian.text = "lima ratus enam"
            
        }
        if NumberInput.text == "507"
        {
            English.text = "five hundred and seven"
            Indonesian.text = "lima ratus tujuh"
            
        }
        if NumberInput.text == "508"
        {
            English.text = "five hundred and eight"
            Indonesian.text = "lima ratus delapan"
            
        }
        if NumberInput.text == "509"
        {
            English.text = "five hundred and nine"
            Indonesian.text = "lima ratus sembilan"
            
        }
        if NumberInput.text == "510"
        {
            English.text = "five hundred and ten"
            Indonesian.text = "lima ratus sepuluh"
            
        }
        if NumberInput.text == "511"
        {
            English.text = "five hundred and eleven"
            Indonesian.text = "lima ratus sebelas"
            
        }
        if NumberInput.text == "512"
        {
            English.text = "five hundred and twelve"
            Indonesian.text = "lima ratus dua belas"
            
        }
        if NumberInput.text == "513"
        {
            English.text = "five hundred and thirteen"
            Indonesian.text = "lima ratus tiga belas"
            
        }
        if NumberInput.text == "514"
        {
            English.text = "five hundred and fourteen"
            Indonesian.text = "lima ratus empat belas"
            
        }
        if NumberInput.text == "515"
        {
            English.text = "five hundred and fifteen"
            Indonesian.text = "lima ratus lima belas"
            
        }
        if NumberInput.text == "516"
        {
            English.text = "five hundred and sixteen"
            Indonesian.text = "lima ratus enam belas"
            
        }
        if NumberInput.text == "517"
        {
            English.text = "five hundred and seventeen"
            Indonesian.text = "lima ratus tujuh belas"
            
        }
        if NumberInput.text == "518"
        {
            English.text = "five hundred and eighteen"
            Indonesian.text = "lima ratus delapan belas"
            
        }
        if NumberInput.text == "519"
        {
            English.text = "five hundred and nineteen"
            Indonesian.text = "lima ratus sembilan belas"
            
        }
        if NumberInput.text == "520"
        {
            English.text = "five hundred and twenty"
            Indonesian.text = "lima ratus dua puluh"
            
        }
        if NumberInput.text == "521"
        {
            English.text = "five hundred and twenty one"
            Indonesian.text = "lima ratus dua puluh satu"
            
        }
        if NumberInput.text == "522"
        {
            English.text = "five hundred and twenty two"
            Indonesian.text = "lima ratus dua puluh dua"
            
        }
        if NumberInput.text == "523"
        {
            English.text = "five hundred and twenty three"
            Indonesian.text = "lima ratus dua puluh tiga"
            
        }
        if NumberInput.text == "524"
        {
            English.text = "five hundred and twenty four"
            Indonesian.text = "lima ratus dua puluh empat"
            
        }
        if NumberInput.text == "525"
        {
            English.text = "five hundred and twenty five"
            Indonesian.text = "lima ratus dua puluh lima"
            
        }
        if NumberInput.text == "526"
        {
            English.text = "five hundred and twenty six"
            Indonesian.text = "lima ratus dua puluh enam"
            
        }
        if NumberInput.text == "527"
        {
            English.text = "five hundred and twenty seven"
            Indonesian.text = "lima ratus dua puluh tujuh"
            
        }
        if NumberInput.text == "528"
        {
            English.text = "five hundred and twenty eight"
            Indonesian.text = "lima ratus dua puluh delapan"
            
        }
        if NumberInput.text == "529"
        {
            English.text = "five hundred and twenty nine"
            Indonesian.text = "lima ratus dua puluh sembilan"
            
        }
        if NumberInput.text == "530"
        {
            English.text = "five hundred and thirty"
            Indonesian.text = "lima ratus tiga puluh"
            
        }
        if NumberInput.text == "531"
        {
            English.text = "five hundred and thirty one"
            Indonesian.text = "lima ratus satu"
            
        }
        if NumberInput.text == "532"
        {
            English.text = "five hundred and thirty two"
            Indonesian.text = "lima ratus tiga puluh dua"
            
        }
        if NumberInput.text == "533"
        {
            English.text = "five hundred and thirty three"
            Indonesian.text = "lima ratus tiga puluh tiga"
            
        }
        if NumberInput.text == "534"
        {
            English.text = "five hundred and thirty four"
            Indonesian.text = "lima ratus tiga puluh empat"
            
        }
        if NumberInput.text == "535"
        {
            English.text = "five hundred and thirty five"
            Indonesian.text = "lima ratus tiga puluh lima"
            
        }
        if NumberInput.text == "536"
        {
            English.text = "five hundred and thirty six"
            Indonesian.text = "lima ratus tiga puluh enam"
            
        }
        if NumberInput.text == "537"
        {
            English.text = "five hundred and thirty seven"
            Indonesian.text = "lima ratus tiga puluh tujuh"
            
        }
        if NumberInput.text == "538"
        {
            English.text = "five hundred and thirty eight"
            Indonesian.text = "lima ratus tiga puluh delapan"
            
        }
        if NumberInput.text == "539"
        {
            English.text = "five hundred and thirty nine"
            Indonesian.text = "lima ratus tiga puluh sembilan"
            
        }
        if NumberInput.text == "540"
        {
            English.text = "five hundred and forty"
            Indonesian.text = "lima ratus empat puluh"
            
        }
        if NumberInput.text == "541"
        {
            English.text = "five hundred and forty one"
            Indonesian.text = "lima ratus empat puluh satu"
            
        }
        if NumberInput.text == "542"
        {
            English.text = "five hundred and forty two"
            Indonesian.text = "lima ratus empat puluh dua"
            
        }
        if NumberInput.text == "543"
        {
            English.text = "five hundred and forty three"
            Indonesian.text = "lima ratus empat puluh tiga"
            
        }
        if NumberInput.text == "544"
        {
            English.text = "five hundred and forty four"
            Indonesian.text = "lima ratus empat puluh empat"
            
        }
        if NumberInput.text == "545"
        {
            English.text = "five hundred and forty five"
            Indonesian.text = "lima ratus empat puluh lima"
            
        }
        if NumberInput.text == "546"
        {
            English.text = "five hundred and forty six"
            Indonesian.text = "lima ratus empat puluh enam"
            
        }
        if NumberInput.text == "547"
        {
            English.text = "five hundred and forty seven"
            Indonesian.text = "lima ratus empat puluh tujuh"
            
        }
        if NumberInput.text == "548"
        {
            English.text = "five hundred and forty eight"
            Indonesian.text = "lima ratus empat puluh delapan"
            
        }
        if NumberInput.text == "549"
        {
            English.text = "five hundred and forty nine"
            Indonesian.text = "lima ratus empat puluh sembilan"
            
        }
        if NumberInput.text == "550"
        {
            English.text = "five hundred and fifty"
            Indonesian.text = "lima ratus lima puluh"
            
        }
        if NumberInput.text == "551"
        {
            English.text = "five hundred and fifty one"
            Indonesian.text = "lima ratus lima puluh satu"
            
        }
        if NumberInput.text == "552"
        {
            English.text = "five hundred and fifty two"
            Indonesian.text = "lima ratus lima puluh dua"
            
        }
        if NumberInput.text == "553"
        {
            English.text = "five hundred and fifty three"
            Indonesian.text = "lima ratus lima puluh tiga"
            
        }
        if NumberInput.text == "554"
        {
            English.text = "five hundred and fifty four"
            Indonesian.text = "lima ratus lima puluh empat"
            
        }
        if NumberInput.text == "555"
        {
            English.text = "five hundred and fifty five"
            Indonesian.text = "lima ratus lima puluh lima"
            
        }
        if NumberInput.text == "556"
        {
            English.text = "five hundred and fifty six"
            Indonesian.text = "lima ratus lima puluh enam"
            
        }
        if NumberInput.text == "557"
        {
            English.text = "five hundred and fifty seven"
            Indonesian.text = "lima ratus lima puluh tujuh"
            
        }
        if NumberInput.text == "558"
        {
            English.text = "five hundred and fifty eight"
            Indonesian.text = "lima ratus lima puluh delapan"
            
        }
        if NumberInput.text == "559"
        {
            English.text = "five hundred and fifty nine"
            Indonesian.text = "lima ratus lima puluh sembilan"
            
        }
        if NumberInput.text == "560"
        {
            English.text = "five hundred and sixty"
            Indonesian.text = "lima ratus enam puluh"
            
        }
        if NumberInput.text == "561"
        {
            English.text = "five hundred and sixty one"
            Indonesian.text = "lima ratus enam puluh satu"
            
        }
        if NumberInput.text == "562"
        {
            English.text = "five hundred and sixty two"
            Indonesian.text = "lima ratus enam puluh dua"
            
        }
        if NumberInput.text == "563"
        {
            English.text = "five hundred and sixty three"
            Indonesian.text = "lima ratus enam puluh tiga"
            
        }
        if NumberInput.text == "564"
        {
            English.text = "five hundred and sixty four"
            Indonesian.text = "lima ratus enam puluh empat"
            
        }
        if NumberInput.text == "565"
        {
            English.text = "five hundred and sixty five"
            Indonesian.text = "lima ratus enam puluh lima"
            
        }
        if NumberInput.text == "566"
        {
            English.text = "five hundred and sixty six"
            Indonesian.text = "lima ratus enam puluh enam"
            
        }
        if NumberInput.text == "567"
        {
            English.text = "five hundred and sixty seven"
            Indonesian.text = "lima ratus enam puluh tujuh"
            
        }
        if NumberInput.text == "568"
        {
            English.text = "five hundred and sixty eight"
            Indonesian.text = "lima ratus enam puluh delapan"
            
        }
        if NumberInput.text == "569"
        {
            English.text = "five hundred and sixty nine"
            Indonesian.text = "lima ratus enam puluh sembilan"
            
        }
        if NumberInput.text == "570"
        {
            English.text = "five hundred and seventy"
            Indonesian.text = "lima ratus tujuh puluh"
            
        }
        if NumberInput.text == "571"
        {
            English.text = "five hundred and seventy one"
            Indonesian.text = "lima ratus tujuh puluh satu"
            
        }
        if NumberInput.text == "572"
        {
            English.text = "five hundred and seventy two"
            Indonesian.text = "lima ratus tujuh puluh dua"
            
        }
        if NumberInput.text == "573"
        {
            English.text = "five hundred and seventy three"
            Indonesian.text = "lima ratus tujuh puluh tiga"
            
        }
        if NumberInput.text == "574"
        {
            English.text = "five hundred and seventy four"
            Indonesian.text = "lima ratus tujuh puluh empat"
            
        }
        if NumberInput.text == "575"
        {
            English.text = "five hundred and seventy five"
            Indonesian.text = "lima ratus tujuh puluh lima"
            
        }
        if NumberInput.text == "576"
        {
            English.text = "five hundred and seventy six"
            Indonesian.text = "lima ratus tujuh puluh enam"
            
        }
        if NumberInput.text == "577"
        {
            English.text = "five hundred and seventy seven"
            Indonesian.text = "lima ratus tujuh puluh tujuh"
            
        }
        if NumberInput.text == "578"
        {
            English.text = "five hundred and seventy eight"
            Indonesian.text = "lima ratus tujuh puluh delapan"
            
        }
        if NumberInput.text == "579"
        {
            English.text = "five hundred and seventy nine"
            Indonesian.text = "lima ratus tujuh puluh sembilan"
            
        }
        if NumberInput.text == "580"
        {
            English.text = "five hundred and eighty"
            Indonesian.text = "lima ratus delapan puluh"
            
        }
        if NumberInput.text == "581"
        {
            English.text = "five hundred and eighty one"
            Indonesian.text = "lima ratus delapan puluh satu"
            
        }
        if NumberInput.text == "582"
        {
            English.text = "five hundred and eighty two"
            Indonesian.text = "lima ratus delapan puluh dua"
            
        }
        if NumberInput.text == "583"
        {
            English.text = "five hundred and eighty three"
            Indonesian.text = "lima ratus delapan puluh tiga"
            
        }
        if NumberInput.text == "584"
        {
            English.text = "five hundred and eighty four"
            Indonesian.text = "lima ratus delapan puluh empat"
            
        }
        if NumberInput.text == "585"
        {
            English.text = "five hundred and eighty five"
            Indonesian.text = "lima ratus delapan puluh lima"
            
        }
        if NumberInput.text == "586"
        {
            English.text = "five hundred and eighty six"
            Indonesian.text = "lima ratus delapan puluh enam"
            
        }
        if NumberInput.text == "587"
        {
            English.text = "five hundred and eighty seven"
            Indonesian.text = "lima ratus delapan puluh tujuh"
            
        }
        if NumberInput.text == "588"
        {
            English.text = "five hundred and eighty eight"
            Indonesian.text = "lima ratus delapan puluh delapan"
            
        }
        if NumberInput.text == "589"
        {
            English.text = "five hundred and eighty nine"
            Indonesian.text = "lima ratus delapan puluh sembilan"
            
        }
        if NumberInput.text == "590"
        {
            English.text = "five hundred and ninety"
            Indonesian.text = "lima ratus sembilan puluh"
            
        }
        if NumberInput.text == "591"
        {
            English.text = "five hundred and ninety one"
            Indonesian.text = "lima ratus sembilan puluh satu"
            
        }
        if NumberInput.text == "592"
        {
            English.text = "five hundred and ninety two"
            Indonesian.text = "lima ratus sembilan puluh dua"
            
        }
        if NumberInput.text == "593"
        {
            English.text = "five hundred and ninety three"
            Indonesian.text = "lima ratus sembilan puluh tiga"
            
        }
        if NumberInput.text == "594"
        {
            English.text = "five hundred and ninety four"
            Indonesian.text = "lima ratus sembilan puluh empat"
            
        }
        if NumberInput.text == "595"
        {
            English.text = "five hundred and ninety five"
            Indonesian.text = "lima ratus sembilan puluh lima"
            
        }
        if NumberInput.text == "596"
        {
            English.text = "five hundred and ninety six"
            Indonesian.text = "lima ratus sembilan puluh enam"
            
        }
        if NumberInput.text == "597"
        {
            English.text = "five hundred and ninety seven"
            Indonesian.text = "lima ratus sembilan puluh tujuh"
            
        }
        if NumberInput.text == "598"
        {
            English.text = "five hundred and ninety eight"
            Indonesian.text = "lima ratus sembilan puluh delapan"
            
        }
        if NumberInput.text == "599"
        {
            English.text = "five hundred and ninety nine"
            Indonesian.text = "lima ratus sembilan puluh sembilan"
            
        }
        if NumberInput.text == "600"
        {
            English.text = "six hundred"
            Indonesian.text = "enam ratus"
            
        }
        if NumberInput.text == "601"
        {
            English.text = "six hundred and one"
            Indonesian.text = "enam ratus satu"
            
        }
        if NumberInput.text == "602"
        {
            English.text = "six hundred and two"
            Indonesian.text = "enam ratus dua"
            
        }
        if NumberInput.text == "603"
        {
            English.text = "six hundred and three"
            Indonesian.text = "enam ratus tiga"
            
        }
        if NumberInput.text == "604"
        {
            English.text = "six hundred and four"
            Indonesian.text = "enam ratus empat"
            
        }
        if NumberInput.text == "605"
        {
            English.text = "six hundred and five"
            Indonesian.text = "enam ratus lima"
            
        }
        if NumberInput.text == "606"
        {
            English.text = "six hundred and six"
            Indonesian.text = "enam ratus enam"
            
        }
        if NumberInput.text == "607"
        {
            English.text = "six hundred and seven"
            Indonesian.text = "enam ratus tujuh"
            
        }
        if NumberInput.text == "608"
        {
            English.text = "six hundred and eight"
            Indonesian.text = "enam ratus delapan"
            
        }
        if NumberInput.text == "609"
        {
            English.text = "six hundred and nine"
            Indonesian.text = "enam ratus sembilan"
            
        }
        if NumberInput.text == "610"
        {
            English.text = "six hundred and ten"
            Indonesian.text = "enam ratus sepuluh"
            
        }
        if NumberInput.text == "611"
        {
            English.text = "six hundred and eleven"
            Indonesian.text = "enam ratus sebelas"
            
        }
        if NumberInput.text == "612"
        {
            English.text = "six hundred and twelve"
            Indonesian.text = "enam ratus dua belas"
            
        }
        if NumberInput.text == "613"
        {
            English.text = "six hundred and thirteen"
            Indonesian.text = "enam ratus tiga belas"
            
        }
        if NumberInput.text == "614"
        {
            English.text = "six hundred and fourteen"
            Indonesian.text = "enam ratus empat belas"
            
        }
        if NumberInput.text == "615"
        {
            English.text = "six hundred and fifteen"
            Indonesian.text = "enam ratus wampt belas"
            
        }
        if NumberInput.text == "616"
        {
            English.text = "six hundred and sixteen"
            Indonesian.text = "enam ratus enam belas"
            
        }
        if NumberInput.text == "617"
        {
            English.text = "six hundred and seventeen"
            Indonesian.text = "enam ratus tujuh belas"
            
        }
        if NumberInput.text == "618"
        {
            English.text = "six hundred and eighteen"
            Indonesian.text = "enam ratus delapan belas"
            
        }
        if NumberInput.text == "619"
        {
            English.text = "six hundred and nineteen"
            Indonesian.text = "enam ratus sembilan belas"
            
        }
        if NumberInput.text == "620"
        {
            English.text = "six hundred and twenty"
            Indonesian.text = "enam ratus dua puluh"
            
        }
        if NumberInput.text == "621"
        {
            English.text = "six hundred and twenty one"
            Indonesian.text = "enam ratus dua puluh satu"
            
        }
        if NumberInput.text == "622"
        {
            English.text = "six hundred and twenty two"
            Indonesian.text = "enam ratus dua puluh dua"
            
        }
        if NumberInput.text == "623"
        {
            English.text = "six hundred and twenty three"
            Indonesian.text = "enam ratus dua puluh tiga"
            
        }
        if NumberInput.text == "624"
        {
            English.text = "six hundred and twenty four"
            Indonesian.text = "enam ratus dua puluh empat"
            
        }
        if NumberInput.text == "625"
        {
            English.text = "six hundred and twenty five"
            Indonesian.text = "enam ratus dua puluh lima"
            
        }
        if NumberInput.text == "626"
        {
            English.text = "six hundred and twenty six"
            Indonesian.text = "enam ratus dua puluh enam"
            
        }
        if NumberInput.text == "627"
        {
            English.text = "six hundred and twenty seven"
            Indonesian.text = "enam ratus dua puluh tujuh"
            
        }
        if NumberInput.text == "628"
        {
            English.text = "six hundred and twenty eight"
            Indonesian.text = "enam ratus dua puluh delapan"
            
        }
        if NumberInput.text == "629"
        {
            English.text = "six hundred and twenty nine"
            Indonesian.text = "enam ratus dua puluh sembilan"
            
        }
        if NumberInput.text == "630"
        {
            English.text = "six hundred and thirty"
            Indonesian.text = "enam ratus tiga puluh"
            
        }
        if NumberInput.text == "631"
        {
            English.text = "six hundred and thirty one"
            Indonesian.text = "enam ratus satu"
            
        }
        if NumberInput.text == "632"
        {
            English.text = "six hundred and thirty two"
            Indonesian.text = "enam ratus tiga puluh dua"
            
        }
        if NumberInput.text == "633"
        {
            English.text = "six hundred and thirty three"
            Indonesian.text = "enam ratus tiga puluh tiga"
            
        }
        if NumberInput.text == "634"
        {
            English.text = "six hundred and thirty four"
            Indonesian.text = "enam ratus tiga puluh empat"
            
        }
        if NumberInput.text == "635"
        {
            English.text = "six hundred and thirty five"
            Indonesian.text = "enam ratus tiga puluh lima"
            
        }
        if NumberInput.text == "636"
        {
            English.text = "six hundred and thirty six"
            Indonesian.text = "enam ratus tiga puluh enam"
            
        }
        if NumberInput.text == "637"
        {
            English.text = "six hundred and thirty seven"
            Indonesian.text = "enam ratus tiga puluh tujuh"
            
        }
        if NumberInput.text == "638"
        {
            English.text = "six hundred and thirty eight"
            Indonesian.text = "enam ratus tiga puluh delapan"
            
        }
        if NumberInput.text == "639"
        {
            English.text = "six hundred and thirty nine"
            Indonesian.text = "enam ratus tiga puluh sembilan"
            
        }
        if NumberInput.text == "640"
        {
            English.text = "six hundred and forty"
            Indonesian.text = "enam ratus empat puluh"
            
        }
        if NumberInput.text == "641"
        {
            English.text = "six hundred and forty one"
            Indonesian.text = "enam ratus empat puluh satu"
            
        }
        if NumberInput.text == "642"
        {
            English.text = "six hundred and forty two"
            Indonesian.text = "enam ratus empat puluh dua"
            
        }
        if NumberInput.text == "643"
        {
            English.text = "six hundred and forty three"
            Indonesian.text = "enam ratus empat puluh tiga"
            
        }
        if NumberInput.text == "644"
        {
            English.text = "six hundred and forty four"
            Indonesian.text = "enam ratus empat puluh empat"
            
        }
        if NumberInput.text == "645"
        {
            English.text = "six hundred and forty five"
            Indonesian.text = "enam ratus empat puluh lima"
            
        }
        if NumberInput.text == "646"
        {
            English.text = "six hundred and forty six"
            Indonesian.text = "enam ratus empat puluh enam"
            
        }
        if NumberInput.text == "647"
        {
            English.text = "six hundred and forty seven"
            Indonesian.text = "enam ratus empat puluh tujuh"
            
        }
        if NumberInput.text == "648"
        {
            English.text = "six hundred and forty eight"
            Indonesian.text = "enam ratus empat puluh delapan"
            
        }
        if NumberInput.text == "649"
        {
            English.text = "six hundred and forty nine"
            Indonesian.text = "enam ratus empat puluh sembilan"
            
        }
        if NumberInput.text == "650"
        {
            English.text = "six hundred and fifty"
            Indonesian.text = "enam ratus lima puluh"
            
        }
        if NumberInput.text == "651"
        {
            English.text = "six hundred and fifty one"
            Indonesian.text = "enam ratus lima puluh satu"
            
        }
        if NumberInput.text == "652"
        {
            English.text = "six hundred and fifty two"
            Indonesian.text = "enam ratus lima puluh dua"
            
        }
        if NumberInput.text == "653"
        {
            English.text = "six hundred and fifty three"
            Indonesian.text = "enam ratus lima puluh tiga"
            
        }
        if NumberInput.text == "654"
        {
            English.text = "six hundred and fifty four"
            Indonesian.text = "enam ratus lima puluh empat"
            
        }
        if NumberInput.text == "655"
        {
            English.text = "six hundred and fifty five"
            Indonesian.text = "enam ratus lima puluh lima"
            
        }
        if NumberInput.text == "656"
        {
            English.text = "six hundred and fifty six"
            Indonesian.text = "enam ratus lima puluh enam"
            
        }
        if NumberInput.text == "657"
        {
            English.text = "six hundred and fifty seven"
            Indonesian.text = "enam ratus lima puluh tujuh"
            
        }
        if NumberInput.text == "658"
        {
            English.text = "six hundred and fifty eight"
            Indonesian.text = "enam ratus lima puluh delapan"
            
        }
        if NumberInput.text == "659"
        {
            English.text = "six hundred and fifty nine"
            Indonesian.text = "enam ratus lima puluh sembilan"
            
        }
        if NumberInput.text == "660"
        {
            English.text = "six hundred and sixty"
            Indonesian.text = "enam ratus enam puluh"
            
        }
        if NumberInput.text == "661"
        {
            English.text = "six hundred and sixty one"
            Indonesian.text = "enam ratus enam puluh satu"
            
        }
        if NumberInput.text == "662"
        {
            English.text = "six hundred and sixty two"
            Indonesian.text = "enam ratus enam puluh dua"
            
        }
        if NumberInput.text == "663"
        {
            English.text = "six hundred and sixty three"
            Indonesian.text = "enam ratus enam puluh tiga"
            
        }
        if NumberInput.text == "664"
        {
            English.text = "six hundred and sixty four"
            Indonesian.text = "enam ratus enam puluh empat"
            
        }
        if NumberInput.text == "665"
        {
            English.text = "six hundred and sixty five"
            Indonesian.text = "enam ratus enam puluh lima"
            
        }
        if NumberInput.text == "666"
        {
            English.text = "six hundred and sixty six"
            Indonesian.text = "enam ratus enam puluh enam"
            
        }
        if NumberInput.text == "667"
        {
            English.text = "six hundred and sixty seven"
            Indonesian.text = "enam ratus enam puluh tujuh"
            
        }
        if NumberInput.text == "668"
        {
            English.text = "six hundred and sixty eight"
            Indonesian.text = "enam ratus enam puluh delapan"
            
        }
        if NumberInput.text == "669"
        {
            English.text = "six hundred and sixty nine"
            Indonesian.text = "enam ratus enam puluh sembilan"
            
        }
        if NumberInput.text == "670"
        {
            English.text = "six hundred and seventy"
            Indonesian.text = "enam ratus tujuh puluh"
            
        }
        if NumberInput.text == "671"
        {
            English.text = "six hundred and seventy one"
            Indonesian.text = "enam ratus tujuh puluh satu"
            
        }
        if NumberInput.text == "672"
        {
            English.text = "six hundred and seventy two"
            Indonesian.text = "enam ratus tujuh puluh dua"
            
        }
        if NumberInput.text == "673"
        {
            English.text = "six hundred and seventy three"
            Indonesian.text = "enam ratus tujuh puluh tiga"
            
        }
        if NumberInput.text == "674"
        {
            English.text = "six hundred and seventy four"
            Indonesian.text = "enam ratus tujuh puluh empat"
            
        }
        if NumberInput.text == "675"
        {
            English.text = "six hundred and seventy five"
            Indonesian.text = "enam ratus tujuh puluh lima"
            
        }
        if NumberInput.text == "676"
        {
            English.text = "six hundred and seventy six"
            Indonesian.text = "enam ratus tujuh puluh enam"
            
        }
        if NumberInput.text == "677"
        {
            English.text = "six hundred and seventy seven"
            Indonesian.text = "enam ratus tujuh puluh tujuh"
            
        }
        if NumberInput.text == "678"
        {
            English.text = "six hundred and seventy eight"
            Indonesian.text = "enam ratus tujuh puluh delapan"
            
        }
        if NumberInput.text == "679"
        {
            English.text = "six hundred and seventy nine"
            Indonesian.text = "enam ratus tujuh puluh sembilan"
            
        }
        if NumberInput.text == "680"
        {
            English.text = "six hundred and eighty"
            Indonesian.text = "enam ratus delapan puluh"
            
        }
        if NumberInput.text == "681"
        {
            English.text = "six hundred and eighty one"
            Indonesian.text = "enam ratus delapan puluh satu"
            
        }
        if NumberInput.text == "682"
        {
            English.text = "six hundred and eighty two"
            Indonesian.text = "enam ratus delapan puluh dua"
            
        }
        if NumberInput.text == "683"
        {
            English.text = "six hundred and eighty three"
            Indonesian.text = "enam ratus delapan puluh tiga"
            
        }
        if NumberInput.text == "684"
        {
            English.text = "six hundred and eighty four"
            Indonesian.text = "enam ratus delapan puluh empat"
            
        }
        if NumberInput.text == "685"
        {
            English.text = "six hundred and eighty five"
            Indonesian.text = "enam ratus delapan puluh lima"
            
        }
        if NumberInput.text == "686"
        {
            English.text = "six hundred and eighty six"
            Indonesian.text = "enam ratus delapan puluh enam"
            
        }
        if NumberInput.text == "687"
        {
            English.text = "six hundred and eighty seven"
            Indonesian.text = "enam ratus delapan puluh tujuh"
            
        }
        if NumberInput.text == "688"
        {
            English.text = "six hundred and eighty eight"
            Indonesian.text = "enam ratus delapan puluh delapan"
            
        }
        if NumberInput.text == "689"
        {
            English.text = "six hundred and eighty nine"
            Indonesian.text = "enam ratus delapan puluh sembilan"
            
        }
        if NumberInput.text == "690"
        {
            English.text = "six hundred and ninety"
            Indonesian.text = "enam ratus sembilan puluh"
            
        }
        if NumberInput.text == "691"
        {
            English.text = "six hundred and ninety one"
            Indonesian.text = "enam ratus sembilan puluh satu"
            
        }
        if NumberInput.text == "692"
        {
            English.text = "six hundred and ninety two"
            Indonesian.text = "enam ratus sembilan puluh dua"
            
        }
        if NumberInput.text == "693"
        {
            English.text = "six hundred and ninety three"
            Indonesian.text = "enam ratus sembilan puluh tiga"
            
        }
        if NumberInput.text == "694"
        {
            English.text = "six hundred and ninety four"
            Indonesian.text = "enam ratus sembilan puluh enam"
            
        }
        if NumberInput.text == "695"
        {
            English.text = "six hundred and ninety five"
            Indonesian.text = "enam ratus sembilan puluh enam"
            
        }
        if NumberInput.text == "696"
        {
            English.text = "six hundred and ninety six"
            Indonesian.text = "enam ratus sembilan puluh enam"
            
        }
        if NumberInput.text == "697"
        {
            English.text = "six hundred and ninety seven"
            Indonesian.text = "enam ratus sembilan puluh tujuh"
            
        }
        if NumberInput.text == "698"
        {
            English.text = "six hundred and ninety eight"
            Indonesian.text = "enam ratus sembilan puluh delapan"
            
        }
        if NumberInput.text == "699"
        {
            English.text = "six hundred and ninety nine"
            Indonesian.text = "enam ratus sembilan puluh sembilan"
            
        }
        if NumberInput.text == "700"
        {
            English.text = "seven hundred"
            Indonesian.text = "tujuh ratus"
            
        }
        if NumberInput.text == "701"
        {
            English.text = "seven hundred and one"
            Indonesian.text = "tujuh ratus satu"
            
        }
        if NumberInput.text == "702"
        {
            English.text = "seven hundred and two"
            Indonesian.text = "tujuh ratus dua"
            
        }
        if NumberInput.text == "703"
        {
            English.text = "seven hundred and three"
            Indonesian.text = "tujuh ratus tiga"
            
        }
        if NumberInput.text == "704"
        {
            English.text = "seven hundred and four"
            Indonesian.text = "tujuh ratus empat"
            
        }
        if NumberInput.text == "705"
        {
            English.text = "seven hundred and five"
            Indonesian.text = "tujuh ratus lima"
            
        }
        if NumberInput.text == "706"
        {
            English.text = "seven hundred and six"
            Indonesian.text = "tujuh ratus enam"
            
        }
        if NumberInput.text == "707"
        {
            English.text = "seven hundred and seven"
            Indonesian.text = "tujuh ratus tujuh"
            
        }
        if NumberInput.text == "708"
        {
            English.text = "seven hundred and eight"
            Indonesian.text = "tujuh ratus delapan"
            
        }
        if NumberInput.text == "709"
        {
            English.text = "seven hundred and nine"
            Indonesian.text = "tujuh ratus sembilan"
            
        }
        if NumberInput.text == "710"
        {
            English.text = "seven hundred and ten"
            Indonesian.text = "tujuh ratus sepuluh"
            
        }
        if NumberInput.text == "711"
        {
            English.text = "seven hundred and eleven"
            Indonesian.text = "tujuh ratus sebelas"
            
        }
        if NumberInput.text == "712"
        {
            English.text = "seven hundred and twelve"
            Indonesian.text = "tujuh ratus dua belas"
            
        }
        if NumberInput.text == "713"
        {
            English.text = "seven hundred and thirteen"
            Indonesian.text = "tujuh ratus tiga belas"
            
        }
        if NumberInput.text == "714"
        {
            English.text = "seven hundred and fourteen"
            Indonesian.text = "tujuh ratus empat belas"
            
        }
        if NumberInput.text == "715"
        {
            English.text = "seven hundred and fifteen"
            Indonesian.text = "tujuh ratus wampt belas"
            
        }
        if NumberInput.text == "716"
        {
            English.text = "seven hundred and sixteen"
            Indonesian.text = "tujuh ratus enam belas"
            
        }
        if NumberInput.text == "717"
        {
            English.text = "seven hundred and seventeen"
            Indonesian.text = "tujuh ratus tujuh belas"
            
        }
        if NumberInput.text == "718"
        {
            English.text = "seven hundred and eighteen"
            Indonesian.text = "tujuh ratus delapan belas"
            
        }
        if NumberInput.text == "719"
        {
            English.text = "seven hundred and nineteen"
            Indonesian.text = "tujuh ratus sembilan belas"
            
        }
        if NumberInput.text == "720"
        {
            English.text = "seven hundred and twenty"
            Indonesian.text = "tujuh ratus dua puluh"
            
        }
        if NumberInput.text == "721"
        {
            English.text = "seven hundred and twenty one"
            Indonesian.text = "tujuh ratus dua puluh satu"
            
        }
        if NumberInput.text == "722"
        {
            English.text = "seven hundred and twenty two"
            Indonesian.text = "tujuh ratus dua puluh dua"
            
        }
        if NumberInput.text == "723"
        {
            English.text = "seven hundred and twenty three"
            Indonesian.text = "tujuh ratus dua puluh tiga"
            
        }
        if NumberInput.text == "724"
        {
            English.text = "seven hundred and twenty four"
            Indonesian.text = "tujuh ratus dua puluh empat"
            
        }
        if NumberInput.text == "725"
        {
            English.text = "seven hundred and twenty five"
            Indonesian.text = "tujuh ratus dua puluh lima"
            
        }
        if NumberInput.text == "726"
        {
            English.text = "seven hundred and twenty six"
            Indonesian.text = "tujuh ratus dua puluh enam"
            
        }
        if NumberInput.text == "727"
        {
            English.text = "seven hundred and twenty seven"
            Indonesian.text = "tujuh ratus dua puluh tujuh"
            
        }
        if NumberInput.text == "728"
        {
            English.text = "seven hundred and twenty eight"
            Indonesian.text = "tujuh ratus dua puluh delapan"
            
        }
        if NumberInput.text == "729"
        {
            English.text = "seven hundred and twenty nine"
            Indonesian.text = "tujuh ratus dua puluh sembilan"
            
        }
        if NumberInput.text == "730"
        {
            English.text = "seven hundred and thirty"
            Indonesian.text = "tujuh ratus tiga puluh"
            
        }
        if NumberInput.text == "731"
        {
            English.text = "seven hundred and thirty one"
            Indonesian.text = "tujuh ratus satu"
            
        }
        if NumberInput.text == "732"
        {
            English.text = "seven hundred and thirty two"
            Indonesian.text = "tujuh ratus tiga puluh dua"
            
        }
        if NumberInput.text == "733"
        {
            English.text = "seven hundred and thirty three"
            Indonesian.text = "tujuh ratus tiga puluh tiga"
            
        }
        if NumberInput.text == "734"
        {
            English.text = "seven hundred and thirty four"
            Indonesian.text = "tujuh ratus tiga puluh empat"
            
        }
        if NumberInput.text == "735"
        {
            English.text = "seven hundred and thirty five"
            Indonesian.text = "tujuh ratus tiga puluh lima"
            
        }
        if NumberInput.text == "736"
        {
            English.text = "seven hundred and thirty six"
            Indonesian.text = "tujuh ratus tiga puluh enam"
            
        }
        if NumberInput.text == "737"
        {
            English.text = "seven hundred and thirty seven"
            Indonesian.text = "tujuh ratus tiga puluh tujuh"
            
        }
        if NumberInput.text == "738"
        {
            English.text = "seven hundred and thirty eight"
            Indonesian.text = "tujuh ratus tiga puluh delapan"
            
        }
        if NumberInput.text == "739"
        {
            English.text = "seven hundred and thirty nine"
            Indonesian.text = "tujuh ratus tiga puluh sembilan"
            
        }
        if NumberInput.text == "740"
        {
            English.text = "seven hundred and forty"
            Indonesian.text = "tujuh ratus empat puluh"
            
        }
        if NumberInput.text == "741"
        {
            English.text = "seven hundred and forty one"
            Indonesian.text = "tujuh ratus empat puluh satu"
            
        }
        if NumberInput.text == "742"
        {
            English.text = "seven hundred and forty two"
            Indonesian.text = "tujuh ratus empat puluh dua"
            
        }
        if NumberInput.text == "743"
        {
            English.text = "seven hundred and forty three"
            Indonesian.text = "tujuh ratus empat puluh tiga"
            
        }
        if NumberInput.text == "744"
        {
            English.text = "seven hundred and forty four"
            Indonesian.text = "tujuh ratus empat puluh empat"
            
        }
        if NumberInput.text == "745"
        {
            English.text = "seven hundred and forty five"
            Indonesian.text = "tujuh ratus empat puluh lima"
            
        }
        if NumberInput.text == "746"
        {
            English.text = "seven hundred and forty six"
            Indonesian.text = "tujuh ratus empat puluh enam"
            
        }
        if NumberInput.text == "747"
        {
            English.text = "seven hundred and forty seven"
            Indonesian.text = "tujuh ratus empat puluh tujuh"
            
        }
        if NumberInput.text == "748"
        {
            English.text = "seven hundred and forty eight"
            Indonesian.text = "tujuh ratus empat puluh delapan"
            
        }
        if NumberInput.text == "749"
        {
            English.text = "seven hundred and forty nine"
            Indonesian.text = "tujuh ratus empat puluh sembilan"
            
        }
        if NumberInput.text == "750"
        {
            English.text = "seven hundred and fifty"
            Indonesian.text = "tujuh ratus lima puluh"
            
        }
        if NumberInput.text == "751"
        {
            English.text = "seven hundred and fifty one"
            Indonesian.text = "tujuh ratus lima puluh satu"
            
        }
        if NumberInput.text == "752"
        {
            English.text = "seven hundred and fifty two"
            Indonesian.text = "tujuh ratus lima puluh dua"
            
        }
        if NumberInput.text == "753"
        {
            English.text = "seven hundred and fifty three"
            Indonesian.text = "tujuh ratus lima puluh tiga"
            
        }
        if NumberInput.text == "754"
        {
            English.text = "seven hundred and fifty four"
            Indonesian.text = "tujuh ratus lima puluh empat"
            
        }
        if NumberInput.text == "755"
        {
            English.text = "seven hundred and fifty five"
            Indonesian.text = "tujuh ratus lima puluh lima"
            
        }
        if NumberInput.text == "756"
        {
            English.text = "seven hundred and fifty six"
            Indonesian.text = "tujuh ratus lima puluh enam"
            
        }
        if NumberInput.text == "757"
        {
            English.text = "seven hundred and fifty seven"
            Indonesian.text = "tujuh ratus lima puluh tujuh"
            
        }
        if NumberInput.text == "758"
        {
            English.text = "seven hundred and fifty eight"
            Indonesian.text = "tujuh ratus lima puluh delapan"
            
        }
        if NumberInput.text == "759"
        {
            English.text = "seven hundred and fifty nine"
            Indonesian.text = "tujuh ratus lima puluh sembilan"
            
        }
        if NumberInput.text == "760"
        {
            English.text = "seven hundred and sixty"
            Indonesian.text = "tujuh ratus enam puluh"
            
        }
        if NumberInput.text == "761"
        {
            English.text = "seven hundred and sixty one"
            Indonesian.text = "tujuh ratus enam puluh satu"
            
        }
        if NumberInput.text == "762"
        {
            English.text = "seven hundred and sixty two"
            Indonesian.text = "tujuh ratus enam puluh dua"
            
        }
        if NumberInput.text == "763"
        {
            English.text = "seven hundred and sixty three"
            Indonesian.text = "tujuh ratus enam puluh tiga"
            
        }
        if NumberInput.text == "764"
        {
            English.text = "seven hundred and sixty four"
            Indonesian.text = "tujuh ratus enam puluh empat"
            
        }
        if NumberInput.text == "765"
        {
            English.text = "seven hundred and sixty five"
            Indonesian.text = "tujuh ratus enam puluh lima"
            
        }
        if NumberInput.text == "767"
        {
            English.text = "seven hundred and sixty seven"
            Indonesian.text = "tujuh ratus enam puluh tujuh"
            
        }
        if NumberInput.text == "767"
        {
            English.text = "seven hundred and sixty seven"
            Indonesian.text = "tujuh ratus enam puluh tujuh"
            
        }
        if NumberInput.text == "768"
        {
            English.text = "seven hundred and sixty eight"
            Indonesian.text = "tujuh ratus enam puluh delapan"
            
        }
        if NumberInput.text == "769"
        {
            English.text = "seven hundred and sixty nine"
            Indonesian.text = "tujuh ratus enam puluh sembilan"
            
        }
        if NumberInput.text == "770"
        {
            English.text = "seven hundred and seventy"
            Indonesian.text = "tujuh ratus tujuh puluh"
            
        }
        if NumberInput.text == "771"
        {
            English.text = "seven hundred and seventy one"
            Indonesian.text = "tujuh ratus tujuh puluh satu"
            
        }
        if NumberInput.text == "772"
        {
            English.text = "seven hundred and seventy two"
            Indonesian.text = "tujuh ratus tujuh puluh dua"
            
        }
        if NumberInput.text == "773"
        {
            English.text = "seven hundred and seventy three"
            Indonesian.text = "tujuh ratus tujuh puluh tiga"
            
        }
        if NumberInput.text == "774"
        {
            English.text = "seven hundred and seventy four"
            Indonesian.text = "tujuh ratus tujuh puluh empat"
            
        }
        if NumberInput.text == "775"
        {
            English.text = "seven hundred and seventy five"
            Indonesian.text = "tujuh ratus tujuh puluh lima"
            
        }
        if NumberInput.text == "776"
        {
            English.text = "seven hundred and seventy six"
            Indonesian.text = "tujuh ratus tujuh puluh enam"
            
        }
        if NumberInput.text == "777"
        {
            English.text = "seven hundred and seventy seven"
            Indonesian.text = "tujuh ratus tujuh puluh tujuh"
            
        }
        if NumberInput.text == "778"
        {
            English.text = "seven hundred and seventy eight"
            Indonesian.text = "tujuh ratus tujuh puluh delapan"
            
        }
        if NumberInput.text == "779"
        {
            English.text = "seven hundred and seventy nine"
            Indonesian.text = "tujuh ratus tujuh puluh sembilan"
            
        }
        if NumberInput.text == "780"
        {
            English.text = "seven hundred and eighty"
            Indonesian.text = "tujuh ratus delapan puluh"
            
        }
        if NumberInput.text == "781"
        {
            English.text = "seven hundred and eighty one"
            Indonesian.text = "tujuh ratus delapan puluh satu"
            
        }
        if NumberInput.text == "782"
        {
            English.text = "seven hundred and eighty two"
            Indonesian.text = "tujuh ratus delapan puluh dua"
            
        }
        if NumberInput.text == "783"
        {
            English.text = "seven hundred and eighty three"
            Indonesian.text = "tujuh ratus delapan puluh tiga"
            
        }
        if NumberInput.text == "784"
        {
            English.text = "seven hundred and eighty four"
            Indonesian.text = "tujuh ratus delapan puluh empat"
            
        }
        if NumberInput.text == "785"
        {
            English.text = "seven hundred and eighty five"
            Indonesian.text = "tujuh ratus delapan puluh lima"
            
        }
        if NumberInput.text == "786"
        {
            English.text = "seven hundred and eighty six"
            Indonesian.text = "tujuh ratus delapan puluh enam"
            
        }
        if NumberInput.text == "787"
        {
            English.text = "seven hundred and eighty seven"
            Indonesian.text = "tujuh ratus delapan puluh tujuh"
            
        }
        if NumberInput.text == "788"
        {
            English.text = "seven hundred and eighty eight"
            Indonesian.text = "tujuh ratus delapan puluh delapan"
            
        }
        if NumberInput.text == "789"
        {
            English.text = "seven hundred and eighty nine"
            Indonesian.text = "tujuh ratus delapan puluh sembilan"
            
        }
        if NumberInput.text == "790"
        {
            English.text = "seven hundred and ninety"
            Indonesian.text = "tujuh ratus sembilan puluh"
            
        }
        if NumberInput.text == "791"
        {
            English.text = "seven hundred and ninety one"
            Indonesian.text = "tujuh ratus sembilan puluh satu"
            
        }
        if NumberInput.text == "792"
        {
            English.text = "seven hundred and ninety two"
            Indonesian.text = "tujuh ratus sembilan puluh dua"
            
        }
        if NumberInput.text == "793"
        {
            English.text = "seven hundred and ninety three"
            Indonesian.text = "tujuh ratus sembilan puluh tiga"
            
        }
        if NumberInput.text == "794"
        {
            English.text = "seven hundred and ninety four"
            Indonesian.text = "tujuh ratus sembilan puluh tujuh"
            
        }
        if NumberInput.text == "795"
        {
            English.text = "seven hundred and ninety five"
            Indonesian.text = "tujuh ratus sembilan puluh tujuh"
            
        }
        if NumberInput.text == "796"
        {
            English.text = "seven hundred and ninety six"
            Indonesian.text = "tujuh ratus sembilan puluh enam"
            
        }
        if NumberInput.text == "797"
        {
            English.text = "seven hundred and ninety seven"
            Indonesian.text = "tujuh ratus sembilan puluh tujuh"
            
        }
        if NumberInput.text == "798"
        {
            English.text = "seven hundred and ninety eight"
            Indonesian.text = "tujuh ratus sembilan puluh delapan"
            
        }
        if NumberInput.text == "799"
        {
            English.text = "seven hundred and ninety nine"
            Indonesian.text = "tujuh ratus sembilan puluh sembilan"
            
        }
        if NumberInput.text == "800"
        {
            English.text = "eight hundred"
            Indonesian.text = "delapan ratus"
            
        }
        if NumberInput.text == "801"
        {
            English.text = "eight hundred and one"
            Indonesian.text = "delapan ratus satu"
            
        }
        if NumberInput.text == "802"
        {
            English.text = "eight hundred and two"
            Indonesian.text = "delapan ratus dua"
            
        }
        if NumberInput.text == "803"
        {
            English.text = "eight hundred and three"
            Indonesian.text = "delapan ratus tiga"
            
        }
        if NumberInput.text == "804"
        {
            English.text = "eight hundred and four"
            Indonesian.text = "delapan ratus empat"
            
        }
        if NumberInput.text == "805"
        {
            English.text = "eight hundred and five"
            Indonesian.text = "delapan ratus lima"
            
        }
        if NumberInput.text == "806"
        {
            English.text = "eight hundred and six"
            Indonesian.text = "delapan ratus enam"
            
        }
        if NumberInput.text == "807"
        {
            English.text = "eight hundred and seven"
            Indonesian.text = "delapan ratus tujuh"
            
        }
        if NumberInput.text == "808"
        {
            English.text = "eight hundred and eight"
            Indonesian.text = "delapan ratus delapan"
            
        }
        if NumberInput.text == "809"
        {
            English.text = "eight hundred and nine"
            Indonesian.text = "delapan ratus sembilan"
            
        }
        if NumberInput.text == "810"
        {
            English.text = "eight hundred and ten"
            Indonesian.text = "delapan ratus sepuluh"
            
        }
        if NumberInput.text == "811"
        {
            English.text = "eight hundred and eleven"
            Indonesian.text = "delapan ratus sebelas"
            
        }
        if NumberInput.text == "812"
        {
            English.text = "eight hundred and twelve"
            Indonesian.text = "delapan ratus dua belas"
            
        }
        if NumberInput.text == "813"
        {
            English.text = "eight hundred and thirteen"
            Indonesian.text = "delapan ratus tiga belas"
            
        }
        if NumberInput.text == "814"
        {
            English.text = "eight hundred and fourteen"
            Indonesian.text = "delapan ratus empat belas"
            
        }
        if NumberInput.text == "815"
        {
            English.text = "eight hundred and fifteen"
            Indonesian.text = "delapan ratus wampt belas"
            
        }
        if NumberInput.text == "816"
        {
            English.text = "eight hundred and sixteen"
            Indonesian.text = "delapan ratus enam belas"
            
        }
        if NumberInput.text == "817"
        {
            English.text = "eight hundred and seventeen"
            Indonesian.text = "delapan ratus tujuh belas"
            
        }
        if NumberInput.text == "818"
        {
            English.text = "eight hundred and eighteen"
            Indonesian.text = "delapan ratus delapan belas"
            
        }
        if NumberInput.text == "819"
        {
            English.text = "eight hundred and nineteen"
            Indonesian.text = "delapan ratus sembilan belas"
            
        }
        if NumberInput.text == "820"
        {
            English.text = "eight hundred and twenty"
            Indonesian.text = "delapan ratus dua puluh"
            
        }
        if NumberInput.text == "821"
        {
            English.text = "eight hundred and twenty one"
            Indonesian.text = "delapan ratus dua puluh satu"
            
        }
        if NumberInput.text == "822"
        {
            English.text = "eight hundred and twenty two"
            Indonesian.text = "delapan ratus dua puluh dua"
            
        }
        if NumberInput.text == "823"
        {
            English.text = "eight hundred and twenty three"
            Indonesian.text = "delapan ratus dua puluh tiga"
            
        }
        if NumberInput.text == "824"
        {
            English.text = "eight hundred and twenty four"
            Indonesian.text = "delapan ratus dua puluh empat"
            
        }
        if NumberInput.text == "825"
        {
            English.text = "eight hundred and twenty five"
            Indonesian.text = "delapan ratus dua puluh lima"
            
        }
        if NumberInput.text == "826"
        {
            English.text = "eight hundred and twenty six"
            Indonesian.text = "delapan ratus dua puluh enam"
            
        }
        if NumberInput.text == "827"
        {
            English.text = "eight hundred and twenty seven"
            Indonesian.text = "delapan ratus dua puluh tujuh"
            
        }
        if NumberInput.text == "828"
        {
            English.text = "eight hundred and twenty eight"
            Indonesian.text = "delapan ratus dua puluh delapan"
            
        }
        if NumberInput.text == "829"
        {
            English.text = "eight hundred and twenty nine"
            Indonesian.text = "delapan ratus dua puluh sembilan"
            
        }
        if NumberInput.text == "830"
        {
            English.text = "eight hundred and thirty"
            Indonesian.text = "delapan ratus tiga puluh"
            
        }
        if NumberInput.text == "831"
        {
            English.text = "eight hundred and thirty one"
            Indonesian.text = "delapan ratus satu"
            
        }
        if NumberInput.text == "832"
        {
            English.text = "eight hundred and thirty two"
            Indonesian.text = "delapan ratus tiga puluh dua"
            
        }
        if NumberInput.text == "833"
        {
            English.text = "eight hundred and thirty three"
            Indonesian.text = "delapan ratus tiga puluh tiga"
            
        }
        if NumberInput.text == "834"
        {
            English.text = "eight hundred and thirty four"
            Indonesian.text = "delapan ratus tiga puluh empat"
            
        }
        if NumberInput.text == "835"
        {
            English.text = "eight hundred and thirty five"
            Indonesian.text = "delapan ratus tiga puluh lima"
            
        }
        if NumberInput.text == "836"
        {
            English.text = "eight hundred and thirty six"
            Indonesian.text = "delapan ratus tiga puluh enam"
            
        }
        if NumberInput.text == "837"
        {
            English.text = "eight hundred and thirty seven"
            Indonesian.text = "delapan ratus tiga puluh tujuh"
            
        }
        if NumberInput.text == "838"
        {
            English.text = "eight hundred and thirty eight"
            Indonesian.text = "delapan ratus tiga puluh delapan"
            
        }
        if NumberInput.text == "839"
        {
            English.text = "eight hundred and thirty nine"
            Indonesian.text = "delapan ratus tiga puluh sembilan"
            
        }
        if NumberInput.text == "840"
        {
            English.text = "eight hundred and forty"
            Indonesian.text = "delapan ratus empat puluh"
            
        }
        if NumberInput.text == "841"
        {
            English.text = "eight hundred and forty one"
            Indonesian.text = "delapan ratus empat puluh satu"
            
        }
        if NumberInput.text == "842"
        {
            English.text = "eight hundred and forty two"
            Indonesian.text = "delapan ratus empat puluh dua"
            
        }
        if NumberInput.text == "843"
        {
            English.text = "eight hundred and forty three"
            Indonesian.text = "delapan ratus empat puluh tiga"
            
        }
        if NumberInput.text == "844"
        {
            English.text = "eight hundred and forty four"
            Indonesian.text = "delapan ratus empat puluh empat"
            
        }
        if NumberInput.text == "845"
        {
            English.text = "eight hundred and forty five"
            Indonesian.text = "delapan ratus empat puluh lima"
            
        }
        if NumberInput.text == "846"
        {
            English.text = "eight hundred and forty six"
            Indonesian.text = "delapan ratus empat puluh enam"
            
        }
        if NumberInput.text == "847"
        {
            English.text = "eight hundred and forty seven"
            Indonesian.text = "delapan ratus empat puluh tujuh"
            
        }
        if NumberInput.text == "848"
        {
            English.text = "eight hundred and forty eight"
            Indonesian.text = "delapan ratus empat puluh delapan"
            
        }
        if NumberInput.text == "849"
        {
            English.text = "eight hundred and forty nine"
            Indonesian.text = "delapan ratus empat puluh sembilan"
            
        }
        if NumberInput.text == "850"
        {
            English.text = "eight hundred and fifty"
            Indonesian.text = "delapan ratus lima puluh"
            
        }
        if NumberInput.text == "851"
        {
            English.text = "eight hundred and fifty one"
            Indonesian.text = "delapan ratus lima puluh satu"
            
        }
        if NumberInput.text == "852"
        {
            English.text = "eight hundred and fifty two"
            Indonesian.text = "delapan ratus lima puluh dua"
            
        }
        if NumberInput.text == "853"
        {
            English.text = "eight hundred and fifty three"
            Indonesian.text = "delapan ratus lima puluh tiga"
            
        }
        if NumberInput.text == "854"
        {
            English.text = "eight hundred and fifty four"
            Indonesian.text = "delapan ratus lima puluh empat"
            
        }
        if NumberInput.text == "855"
        {
            English.text = "eight hundred and fifty five"
            Indonesian.text = "delapan ratus lima puluh lima"
            
        }
        if NumberInput.text == "856"
        {
            English.text = "eight hundred and fifty six"
            Indonesian.text = "delapan ratus lima puluh enam"
            
        }
        if NumberInput.text == "857"
        {
            English.text = "eight hundred and fifty seven"
            Indonesian.text = "delapan ratus lima puluh tujuh"
            
        }
        if NumberInput.text == "858"
        {
            English.text = "eight hundred and fifty eight"
            Indonesian.text = "delapan ratus lima puluh delapan"
            
        }
        if NumberInput.text == "859"
        {
            English.text = "eight hundred and fifty nine"
            Indonesian.text = "delapan ratus lima puluh sembilan"
            
        }
        if NumberInput.text == "860"
        {
            English.text = "eight hundred and sixty"
            Indonesian.text = "delapan ratus enam puluh"
            
        }
        if NumberInput.text == "861"
        {
            English.text = "eight hundred and sixty one"
            Indonesian.text = "delapan ratus enam puluh satu"
            
        }
        if NumberInput.text == "862"
        {
            English.text = "eight hundred and sixty two"
            Indonesian.text = "delapan ratus enam puluh dua"
            
        }
        if NumberInput.text == "863"
        {
            English.text = "eight hundred and sixty three"
            Indonesian.text = "delapan ratus enam puluh tiga"
            
        }
        if NumberInput.text == "864"
        {
            English.text = "eight hundred and sixty four"
            Indonesian.text = "delapan ratus enam puluh empat"
            
        }
        if NumberInput.text == "865"
        {
            English.text = "eight hundred and sixty five"
            Indonesian.text = "delapan ratus enam puluh lima"
            
        }
        if NumberInput.text == "866"
        {
            English.text = "eight hundred and sixty six"
            Indonesian.text = "delapan ratus enam puluh enam"
            
        }
        if NumberInput.text == "867"
        {
            English.text = "eight hundred and sixty seven"
            Indonesian.text = "delapan ratus enam puluh tujuh"
            
        }
        if NumberInput.text == "868"
        {
            English.text = "eight hundred and sixty eight"
            Indonesian.text = "delapan ratus enam puluh delapan"
            
        }
        if NumberInput.text == "869"
        {
            English.text = "eight hundred and sixty nine"
            Indonesian.text = "delapan ratus enam puluh sembilan"
            
        }
        if NumberInput.text == "870"
        {
            English.text = "eight hundred and seventy"
            Indonesian.text = "delapan ratus delapan puluh"
            
        }
        if NumberInput.text == "871"
        {
            English.text = "eight hundred and seventy one"
            Indonesian.text = "delapan ratus delapan puluh satu"
            
        }
        if NumberInput.text == "872"
        {
            English.text = "eight hundred and seventy two"
            Indonesian.text = "delapan ratus delapan puluh dua"
            
        }
        if NumberInput.text == "873"
        {
            English.text = "eight hundred and seventy three"
            Indonesian.text = "delapan ratus delapan puluh tiga"
            
        }
        if NumberInput.text == "874"
        {
            English.text = "eight hundred and seventy four"
            Indonesian.text = "delapan ratus delapan puluh empat"
            
        }
        if NumberInput.text == "875"
        {
            English.text = "eight hundred and seventy five"
            Indonesian.text = "delapan ratus delapan puluh lima"
            
        }
        if NumberInput.text == "876"
        {
            English.text = "eight hundred and seventy six"
            Indonesian.text = "delapan ratus delapan puluh enam"
            
        }
        if NumberInput.text == "877"
        {
            English.text = "eight hundred and seventy seven"
            Indonesian.text = "delapan ratus delapan puluh tujuh"
            
        }
        if NumberInput.text == "878"
        {
            English.text = "eight hundred and seventy eight"
            Indonesian.text = "delapan ratus delapan puluh delapan"
            
        }
        if NumberInput.text == "879"
        {
            English.text = "eight hundred and seventy nine"
            Indonesian.text = "delapan ratus delapan puluh sembilan"
            
        }
        if NumberInput.text == "880"
        {
            English.text = "eight hundred and eighty"
            Indonesian.text = "delapan ratus delapan puluh"
            
        }
        if NumberInput.text == "881"
        {
            English.text = "eight hundred and eighty one"
            Indonesian.text = "delapan ratus delapan puluh satu"
            
        }
        if NumberInput.text == "882"
        {
            English.text = "eight hundred and eighty two"
            Indonesian.text = "delapan ratus delapan puluh dua"
            
        }
        if NumberInput.text == "883"
        {
            English.text = "eight hundred and eighty three"
            Indonesian.text = "delapan ratus delapan puluh tiga"
            
        }
        if NumberInput.text == "884"
        {
            English.text = "eight hundred and eighty four"
            Indonesian.text = "delapan ratus delapan puluh empat"
            
        }
        if NumberInput.text == "885"
        {
            English.text = "eight hundred and eighty five"
            Indonesian.text = "delapan ratus delapan puluh lima"
            
        }
        if NumberInput.text == "886"
        {
            English.text = "eight hundred and eighty six"
            Indonesian.text = "delapan ratus delapan puluh enam"
            
        }
        if NumberInput.text == "887"
        {
            English.text = "eight hundred and eighty seven"
            Indonesian.text = "delapan ratus delapan puluh tujuh"
            
        }
        if NumberInput.text == "888"
        {
            English.text = "eight hundred and eighty eight"
            Indonesian.text = "delapan ratus delapan puluh delapan"
            
        }
        if NumberInput.text == "889"
        {
            English.text = "eight hundred and eighty nine"
            Indonesian.text = "delapan ratus delapan puluh sembilan"
            
        }
        if NumberInput.text == "890"
        {
            English.text = "eight hundred and ninety"
            Indonesian.text = "delapan ratus sembilan puluh"
            
        }
        if NumberInput.text == "891"
        {
            English.text = "eight hundred and ninety one"
            Indonesian.text = "delapan ratus sembilan puluh satu"
            
        }
        if NumberInput.text == "892"
        {
            English.text = "eight hundred and ninety two"
            Indonesian.text = "delapan ratus sembilan puluh dua"
            
        }
        if NumberInput.text == "893"
        {
            English.text = "eight hundred and ninety three"
            Indonesian.text = "delapan ratus sembilan puluh tiga"
            
        }
        if NumberInput.text == "894"
        {
            English.text = "eight hundred and ninety four"
            Indonesian.text = "delapan ratus sembilan puluh delapan"
            
        }
        if NumberInput.text == "895"
        {
            English.text = "eight hundred and ninety five"
            Indonesian.text = "delapan ratus sembilan puluh delapan"
            
        }
        if NumberInput.text == "896"
        {
            English.text = "eight hundred and ninety six"
            Indonesian.text = "delapan ratus sembilan puluh enam"
            
        }
        if NumberInput.text == "897"
        {
            English.text = "eight hundred and ninety seven"
            Indonesian.text = "delapan ratus sembilan puluh tujuh"
            
        }
        if NumberInput.text == "898"
        {
            English.text = "eight hundred and ninety eight"
            Indonesian.text = "delapan ratus sembilan puluh delapan"
            
        }
        if NumberInput.text == "899"
        {
            English.text = "eight hundred and ninety nine"
            Indonesian.text = "delapan ratus sembilan puluh sembilan"
            
        }
        if NumberInput.text == "900"
        {
            English.text = "nine hundred"
            Indonesian.text = "sembilan ratus"
            
        }
        if NumberInput.text == "901"
        {
            English.text = "nine hundred and one"
            Indonesian.text = "sembilan ratus satu"
            
        }
        if NumberInput.text == "902"
        {
            English.text = "nine hundred and two"
            Indonesian.text = "sembilan ratus dua"
            
        }
        if NumberInput.text == "903"
        {
            English.text = "nine hundred and three"
            Indonesian.text = "sembilan ratus tiga"
            
        }
        if NumberInput.text == "904"
        {
            English.text = "nine hundred and four"
            Indonesian.text = "sembilan ratus empat"
            
        }
        if NumberInput.text == "905"
        {
            English.text = "nine hundred and five"
            Indonesian.text = "sembilan ratus lima"
            
        }
        if NumberInput.text == "906"
        {
            English.text = "nine hundred and six"
            Indonesian.text = "sembilan ratus enam"
            
        }
        if NumberInput.text == "907"
        {
            English.text = "nine hundred and seven"
            Indonesian.text = "sembilan ratus tujuh"
            
        }
        if NumberInput.text == "908"
        {
            English.text = "nine hundred and eight"
            Indonesian.text = "sembilan ratus delapan"
            
        }
        if NumberInput.text == "909"
        {
            English.text = "nine hundred and nine"
            Indonesian.text = "sembilan ratus sembilan"
            
        }
        if NumberInput.text == "910"
        {
            English.text = "nine hundred and ten"
            Indonesian.text = "sembilan ratus sepuluh"
            
        }
        if NumberInput.text == "911"
        {
            English.text = "nine hundred and eleven"
            Indonesian.text = "sembilan ratus sebelas"
            
        }
        if NumberInput.text == "912"
        {
            English.text = "nine hundred and twelve"
            Indonesian.text = "sembilan ratus dua belas"
            
        }
        if NumberInput.text == "913"
        {
            English.text = "nine hundred and thirteen"
            Indonesian.text = "sembilan ratus tiga belas"
            
        }
        if NumberInput.text == "914"
        {
            English.text = "nine hundred and fourteen"
            Indonesian.text = "sembilan ratus empat belas"
            
        }
        if NumberInput.text == "915"
        {
            English.text = "nine hundred and fifteen"
            Indonesian.text = "sembilan ratus wampt belas"
            
        }
        if NumberInput.text == "916"
        {
            English.text = "nine hundred and sixteen"
            Indonesian.text = "sembilan ratus enam belas"
            
        }
        if NumberInput.text == "917"
        {
            English.text = "nine hundred and seventeen"
            Indonesian.text = "sembilan ratus tujuh belas"
            
        }
        if NumberInput.text == "918"
        {
            English.text = "nine hundred and eighteen"
            Indonesian.text = "sembilan ratus delapan belas"
            
        }
        if NumberInput.text == "919"
        {
            English.text = "nine hundred and nineteen"
            Indonesian.text = "sembilan ratus sembilan belas"
            
        }
        if NumberInput.text == "920"
        {
            English.text = "nine hundred and twenty"
            Indonesian.text = "sembilan ratus dua puluh"
            
        }
        if NumberInput.text == "921"
        {
            English.text = "nine hundred and twenty one"
            Indonesian.text = "sembilan ratus dua puluh satu"
            
        }
        if NumberInput.text == "922"
        {
            English.text = "nine hundred and twenty two"
            Indonesian.text = "sembilan ratus dua puluh dua"
            
        }
        if NumberInput.text == "923"
        {
            English.text = "nine hundred and twenty three"
            Indonesian.text = "sembilan ratus dua puluh tiga"
            
        }
        if NumberInput.text == "924"
        {
            English.text = "nine hundred and twenty four"
            Indonesian.text = "sembilan ratus dua puluh empat"
            
        }
        if NumberInput.text == "925"
        {
            English.text = "nine hundred and twenty five"
            Indonesian.text = "sembilan ratus dua puluh lima"
            
        }
        if NumberInput.text == "926"
        {
            English.text = "nine hundred and twenty six"
            Indonesian.text = "sembilan ratus dua puluh enam"
            
        }
        if NumberInput.text == "927"
        {
            English.text = "nine hundred and twenty seven"
            Indonesian.text = "sembilan ratus dua puluh tujuh"
            
        }
        if NumberInput.text == "928"
        {
            English.text = "nine hundred and twenty eight"
            Indonesian.text = "sembilan ratus dua puluh delapan"
            
        }
        if NumberInput.text == "929"
        {
            English.text = "nine hundred and twenty nine"
            Indonesian.text = "sembilan ratus dua puluh sembilan"
            
        }
        if NumberInput.text == "930"
        {
            English.text = "nine hundred and thirty"
            Indonesian.text = "sembilan ratus tiga puluh"
            
        }
        if NumberInput.text == "931"
        {
            English.text = "nine hundred and thirty one"
            Indonesian.text = "sembilan ratus satu"
            
        }
        if NumberInput.text == "932"
        {
            English.text = "nine hundred and thirty two"
            Indonesian.text = "sembilan ratus tiga puluh dua"
            
        }
        if NumberInput.text == "933"
        {
            English.text = "nine hundred and thirty three"
            Indonesian.text = "sembilan ratus tiga puluh tiga"
            
        }
        if NumberInput.text == "934"
        {
            English.text = "nine hundred and thirty four"
            Indonesian.text = "sembilan ratus tiga puluh empat"
            
        }
        if NumberInput.text == "935"
        {
            English.text = "nine hundred and thirty five"
            Indonesian.text = "sembilan ratus tiga puluh lima"
            
        }
        if NumberInput.text == "936"
        {
            English.text = "nine hundred and thirty six"
            Indonesian.text = "sembilan ratus tiga puluh enam"
            
        }
        if NumberInput.text == "937"
        {
            English.text = "nine hundred and thirty seven"
            Indonesian.text = "sembilan ratus tiga puluh tujuh"
            
        }
        if NumberInput.text == "938"
        {
            English.text = "nine hundred and thirty eight"
            Indonesian.text = "sembilan ratus tiga puluh delapan"
            
        }
        if NumberInput.text == "939"
        {
            English.text = "nine hundred and thirty nine"
            Indonesian.text = "sembilan ratus tiga puluh sembilan"
            
        }
        if NumberInput.text == "940"
        {
            English.text = "nine hundred and forty"
            Indonesian.text = "sembilan ratus empat puluh"
            
        }
        if NumberInput.text == "941"
        {
            English.text = "nine hundred and forty one"
            Indonesian.text = "sembilan ratus empat puluh satu"
            
        }
        if NumberInput.text == "942"
        {
            English.text = "nine hundred and forty two"
            Indonesian.text = "sembilan ratus empat puluh dua"
            
        }
        if NumberInput.text == "943"
        {
            English.text = "nine hundred and forty three"
            Indonesian.text = "sembilan ratus empat puluh tiga"
            
        }
        if NumberInput.text == "944"
        {
            English.text = "nine hundred and forty four"
            Indonesian.text = "sembilan ratus empat puluh empat"
            
        }
        if NumberInput.text == "945"
        {
            English.text = "nine hundred and forty five"
            Indonesian.text = "sembilan ratus empat puluh lima"
            
        }
        if NumberInput.text == "946"
        {
            English.text = "nine hundred and forty six"
            Indonesian.text = "sembilan ratus empat puluh enam"
            
        }
        if NumberInput.text == "947"
        {
            English.text = "nine hundred and forty seven"
            Indonesian.text = "sembilan ratus empat puluh tujuh"
            
        }
        if NumberInput.text == "948"
        {
            English.text = "nine hundred and forty eight"
            Indonesian.text = "sembilan ratus empat puluh delapan"
            
        }
        if NumberInput.text == "949"
        {
            English.text = "nine hundred and forty nine"
            Indonesian.text = "sembilan ratus empat puluh sembilan"
            
        }
        if NumberInput.text == "950"
        {
            English.text = "nine hundred and fifty"
            Indonesian.text = "sembilan ratus lima puluh"
            
        }
        if NumberInput.text == "951"
        {
            English.text = "nine hundred and fifty one"
            Indonesian.text = "sembilan ratus lima puluh satu"
            
        }
        if NumberInput.text == "952"
        {
            English.text = "nine hundred and fifty two"
            Indonesian.text = "sembilan ratus lima puluh dua"
            
        }
        if NumberInput.text == "953"
        {
            English.text = "nine hundred and fifty three"
            Indonesian.text = "sembilan ratus lima puluh tiga"
            
        }
        if NumberInput.text == "954"
        {
            English.text = "nine hundred and fifty four"
            Indonesian.text = "sembilan ratus lima puluh empat"
            
        }
        if NumberInput.text == "955"
        {
            English.text = "nine hundred and fifty five"
            Indonesian.text = "sembilan ratus lima puluh lima"
            
        }
        if NumberInput.text == "956"
        {
            English.text = "nine hundred and fifty six"
            Indonesian.text = "sembilan ratus lima puluh enam"
            
        }
        if NumberInput.text == "957"
        {
            English.text = "nine hundred and fifty seven"
            Indonesian.text = "sembilan ratus lima puluh tujuh"
            
        }
        if NumberInput.text == "958"
        {
            English.text = "nine hundred and fifty eight"
            Indonesian.text = "sembilan ratus lima puluh delapan"
            
        }
        if NumberInput.text == "959"
        {
            English.text = "nine hundred and fifty nine"
            Indonesian.text = "sembilan ratus lima puluh sembilan"
            
        }
        if NumberInput.text == "960"
        {
            English.text = "nine hundred and sixty"
            Indonesian.text = "sembilan ratus enam puluh"
            
        }
        if NumberInput.text == "961"
        {
            English.text = "nine hundred and sixty one"
            Indonesian.text = "sembilan ratus enam puluh satu"
            
        }
        if NumberInput.text == "962"
        {
            English.text = "nine hundred and sixty two"
            Indonesian.text = "sembilan ratus enam puluh dua"
            
        }
        if NumberInput.text == "963"
        {
            English.text = "nine hundred and sixty three"
            Indonesian.text = "sembilan ratus enam puluh tiga"
            
        }
        if NumberInput.text == "964"
        {
            English.text = "nine hundred and sixty four"
            Indonesian.text = "sembilan ratus enam puluh empat"
            
        }
        if NumberInput.text == "965"
        {
            English.text = "nine hundred and sixty five"
            Indonesian.text = "sembilan ratus enam puluh lima"
            
        }
        if NumberInput.text == "966"
        {
            English.text = "nine hundred and sixty six"
            Indonesian.text = "sembilan ratus enam puluh enam"
            
        }
        if NumberInput.text == "967"
        {
            English.text = "nine hundred and sixty seven"
            Indonesian.text = "sembilan ratus enam puluh tujuh"
            
        }
        if NumberInput.text == "968"
        {
            English.text = "nine hundred and sixty eight"
            Indonesian.text = "sembilan ratus enam puluh delapan"
            
        }
        if NumberInput.text == "969"
        {
            English.text = "nine hundred and sixty nine"
            Indonesian.text = "sembilan ratus enam puluh sembilan"
            
        }
        if NumberInput.text == "970"
        {
            English.text = "nine hundred and seventy"
            Indonesian.text = "sembilan ratus sembilan puluh"
            
        }
        if NumberInput.text == "971"
        {
            English.text = "nine hundred and seventy one"
            Indonesian.text = "sembilan ratus sembilan puluh satu"
            
        }
        if NumberInput.text == "972"
        {
            English.text = "nine hundred and seventy two"
            Indonesian.text = "sembilan ratus sembilan puluh dua"
            
        }
        if NumberInput.text == "973"
        {
            English.text = "nine hundred and seventy three"
            Indonesian.text = "sembilan ratus sembilan puluh tiga"
            
        }
        if NumberInput.text == "974"
        {
            English.text = "nine hundred and seventy four"
            Indonesian.text = "sembilan ratus sembilan puluh empat"
            
        }
        if NumberInput.text == "975"
        {
            English.text = "nine hundred and seventy five"
            Indonesian.text = "sembilan ratus sembilan puluh lima"
            
        }
        if NumberInput.text == "976"
        {
            English.text = "nine hundred and seventy six"
            Indonesian.text = "sembilan ratus sembilan puluh enam"
            
        }
        if NumberInput.text == "977"
        {
            English.text = "nine hundred and seventy seven"
            Indonesian.text = "sembilan ratus sembilan puluh tujuh"
            
        }
        if NumberInput.text == "978"
        {
            English.text = "nine hundred and seventy eight"
            Indonesian.text = "sembilan ratus sembilan puluh delapan"
            
        }
        if NumberInput.text == "979"
        {
            English.text = "nine hundred and seventy nine"
            Indonesian.text = "sembilan ratus sembilan puluh sembilan"
            
        }
        if NumberInput.text == "980"
        {
            English.text = "nine hundred and eighty"
            Indonesian.text = "sembilan ratus delapan puluh"
            
        }
        if NumberInput.text == "981"
        {
            English.text = "nine hundred and eighty one"
            Indonesian.text = "sembilan ratus delapan puluh satu"
            
        }
        if NumberInput.text == "982"
        {
            English.text = "nine hundred and eighty two"
            Indonesian.text = "sembilan ratus delapan puluh dua"
            
        }
        if NumberInput.text == "983"
        {
            English.text = "nine hundred and eighty three"
            Indonesian.text = "sembilan ratus delapan puluh tiga"
            
        }
        if NumberInput.text == "984"
        {
            English.text = "nine hundred and eighty four"
            Indonesian.text = "sembilan ratus delapan puluh empat"
            
        }
        if NumberInput.text == "985"
        {
            English.text = "nine hundred and eighty five"
            Indonesian.text = "sembilan ratus delapan puluh lima"
            
        }
        if NumberInput.text == "986"
        {
            English.text = "nine hundred and eighty six"
            Indonesian.text = "sembilan ratus delapan puluh enam"
            
        }
        if NumberInput.text == "987"
        {
            English.text = "nine hundred and eighty seven"
            Indonesian.text = "sembilan ratus delapan puluh tujuh"
            
        }
        if NumberInput.text == "988"
        {
            English.text = "nine hundred and eighty eight"
            Indonesian.text = "sembilan ratus delapan puluh delapan"
            
        }
        if NumberInput.text == "989"
        {
            English.text = "nine hundred and eighty nine"
            Indonesian.text = "sembilan ratus delapan puluh sembilan"
            
        }
        if NumberInput.text == "990"
        {
            English.text = "nine hundred and ninety"
            Indonesian.text = "sembilan ratus sembilan puluh"
            
        }
        if NumberInput.text == "991"
        {
            English.text = "nine hundred and ninety one"
            Indonesian.text = "sembilan ratus sembilan puluh satu"
            
        }
        if NumberInput.text == "992"
        {
            English.text = "nine hundred and ninety two"
            Indonesian.text = "sembilan ratus sembilan puluh dua"
            
        }
        if NumberInput.text == "993"
        {
            English.text = "nine hundred and ninety three"
            Indonesian.text = "sembilan ratus sembilan puluh tiga"
            
        }
        if NumberInput.text == "994"
        {
            English.text = "nine hundred and ninety four"
            Indonesian.text = "sembilan ratus sembilan puluh sembilan"
            
        }
        if NumberInput.text == "995"
        {
            English.text = "nine hundred and ninety five"
            Indonesian.text = "sembilan ratus sembilan puluh sembilan"
            
        }
        if NumberInput.text == "996"
        {
            English.text = "nine hundred and ninety six"
            Indonesian.text = "sembilan ratus sembilan puluh enam"
            
        }
        if NumberInput.text == "997"
        {
            English.text = "nine hundred and ninety seven"
            Indonesian.text = "sembilan ratus sembilan puluh tujuh"
            
        }
        if NumberInput.text == "998"
        {
            English.text = "nine hundred and ninety eight"
            Indonesian.text = "sembilan ratus sembilan puluh eight"
            
        }
        if NumberInput.text == "999"
        {
            English.text = "nine hundred and ninety nine"
            Indonesian.text = "sembilan ratus sembilan puluh sembilan"
            
        }
        if NumberInput.text == "1000"
        {
            English.text = "one thousand"
            Indonesian.text = "seribu"
            
        }
        if English.text == ""
        {
            let alertView = UIAlertController(title: "Names and Numbers", message: "Please enter a valid number less than 1000", preferredStyle: .alert)
            let action = UIAlertAction(title: "OK", style: .default, handler: { (alert) in
                
            })
            alertView.addAction(action)
            self.present(alertView, animated: true, completion: nil)
            return;
        }

    }
    @IBOutlet weak var Enter: UIButton!
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

